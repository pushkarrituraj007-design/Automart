/* AutoMart Vehicle Studio — interactive system explorer (illustrative geometry, not OEM CAD). */
(() => {
  const canvas = document.getElementById('vehicle3d');
  if (!canvas || !window.THREE) return;
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const modelName = `${canvas.dataset.vehicleMake || ''} ${canvas.dataset.vehicleModel || ''}`.toLowerCase();
  const bike = /apache|splendor|classic|pulsar|activa|scooter|motorcycle|bike|scooty/.test(modelName);
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x101b20);
  const camera = new THREE.PerspectiveCamera(35, 1, .1, 100);
  const renderer = new THREE.WebGLRenderer({canvas, antialias:true, alpha:false});
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.8)); renderer.shadowMap.enabled = true;
  if (THREE.SRGBColorSpace) renderer.outputColorSpace = THREE.SRGBColorSpace; else renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.15;
  scene.add(new THREE.HemisphereLight(0xe5eee9, 0x26343b, 1.8));
  const key = new THREE.DirectionalLight(0xfff2df, 2.5); key.position.set(4,8,6); key.castShadow=true; scene.add(key);
  const fill = new THREE.DirectionalLight(0x8caeb0, 1.4); fill.position.set(-5,3,-4); scene.add(fill);
  const rim = new THREE.PointLight(0xd98767, .8, 20); rim.position.set(1,3,-4); scene.add(rim);
  const vehicle = new THREE.Group(); scene.add(vehicle);
  const markerLayer = new THREE.Group(); scene.add(markerLayer);
  const groups = {};
  ['exterior','powertrain','running','electrical','cabin'].forEach(k => { groups[k]=new THREE.Group(); vehicle.add(groups[k]); });
  const mat = (color, metalness=.2, roughness=.55, extra={}) => new THREE.MeshStandardMaterial({color,metalness,roughness,...extra});
  const paint=mat(0xb74e35,.72,.27), paintDark=mat(0x542c28,.55,.34), rubber=mat(0x111719,.05,.88), alloy=mat(0xaeb9b7,.82,.25), steel=mat(0x56646a,.8,.34), glass=mat(0x172d35,.55,.18,{transparent:true,opacity:.88}), black=mat(0x20292d,.28,.52), lamp=mat(0xf0e8c8,.25,.18,{emissive:0x8b7548,emissiveIntensity:.45}), red=mat(0x8d2926,.25,.3,{emissive:0x3d0807,emissiveIntensity:.35});
  const add=(g,geo,m,x=0,y=0,z=0,rx=0,ry=0,rz=0)=>{const o=new THREE.Mesh(geo,m);o.position.set(x,y,z);o.rotation.set(rx,ry,rz);o.castShadow=true;o.receiveShadow=true;g.add(o);return o;};
  const box=(g,w,h,d,m,x,y,z,rx=0,ry=0,rz=0)=>add(g,new THREE.BoxGeometry(w,h,d),m,x,y,z,rx,ry,rz);
  const cyl=(g,r1,r2,h,m,x,y,z,rx=0,ry=0,rz=0)=>add(g,new THREE.CylinderGeometry(r1,r2,h,32),m,x,y,z,rx,ry,rz);
  const sphere=(g,sx,sy,sz,m,x,y,z)=>{const o=add(g,new THREE.SphereGeometry(1,28,20),m,x,y,z);o.scale.set(sx,sy,sz);return o;};
  const torus=(g,r,t,m,x,y,z,rx=Math.PI/2)=>add(g,new THREE.TorusGeometry(r,t,12,48),m,x,y,z,rx);
  const markers=[];
  const marker=(key,label,x,y,z)=>{const group=new THREE.Group();group.position.set(x,y,z);markerLayer.add(group);const dot=new THREE.Mesh(new THREE.SphereGeometry(.075,18,14),mat(0xe5a078,.1,.25,{emissive:0x8a3d22,emissiveIntensity:.65}));group.add(dot);const halo=new THREE.Mesh(new THREE.TorusGeometry(.13,.012,8,32),mat(0xe9bd8a,.2,.25,{emissive:0x8b5c32,emissiveIntensity:.4}));group.add(halo);markers.push({group,key,label,dot});return group;};
  const wheels=[];
  function wheel(g,x,z,r,front=false){const hub=new THREE.Group();hub.position.set(x,r,z);g.add(hub);const tire=add(hub,new THREE.TorusGeometry(r*.84,r*.16,16,48),rubber,0,0,0,0,Math.PI/2,0);const rim=cyl(hub,r*.48,r*.48,.11,alloy,0,0,0,0,0,Math.PI/2);const inner=cyl(hub,r*.22,r*.22,.13,steel,0,0,0,0,0,Math.PI/2);for(let i=0;i<10;i++){const a=i*Math.PI/5;box(hub,.025,r*.68,.035,alloy,0,Math.cos(a)*r*.34,Math.sin(a)*r*.34);}wheels.push(hub);return hub;}
  if (bike) {
    // Exterior / bodywork
    sphere(groups.exterior,.34,.27,.53,paint,0,1.22,.12);
    box(groups.exterior,.42,.12,.64,paintDark,0,1.04,-.55);
    sphere(groups.exterior,.25,.1,.5,black,0,1.48,-.48);
    box(groups.exterior,.16,.06,.55,alloy,0,1.02,-.86);
    sphere(groups.exterior,.18,.13,.12,lamp,0,1.62,1.27);
    box(groups.exterior,.66,.055,.08,alloy,0,1.77,1.06);
    box(groups.exterior,.36,.1,.22,paint,0,1.12,-1.17);
    // Powertrain: crankcase, cylinder, head, intake and exhaust
    const eng=groups.powertrain;
    sphere(eng,.31,.3,.36,steel,0,.92,-.18);
    box(eng,.36,.44,.3,alloy,0,1.2,-.12,.18);
    cyl(eng,.17,.2,.38,steel,0,1.45,-.1,Math.PI/2);
    box(eng,.4,.09,.28,black,0,1.53,-.1);
    cyl(eng,.065,.075,1.05,alloy,.28,.77,-.72,Math.PI/2,0,Math.PI/2);
    sphere(eng,.12,.12,.25,black,.28,.77,-1.24);
    // Running gear: forks, swingarm, brakes, chain and discs
    const run=groups.running;
    wheels.push(wheel(run,0,1.35,.43,true),wheel(run,0,-1.3,.43,false));
    cyl(run,.035,.035,1.13,alloy,-.13,1.08,1.03,.18,0,-.1);cyl(run,.035,.035,1.13,alloy,.13,1.08,1.03,.18,0,.1);
    box(run,.09,.1,1.12,steel,0,.82,-.63,.28);
    torus(run,.27,.025,alloy,0,.43,1.36);torus(run,.24,.025,alloy,0,.43,-1.3);
    cyl(run,.035,.035,.62,steel,-.25,.45,-.25,0,0,Math.PI/2);
    // Electrical: battery, ignition coil, harness and lamps
    const elec=groups.electrical;
    box(elec,.2,.24,.25,black,-.23,1.08,-.42);box(elec,.12,.06,.1,red,-.23,1.23,-.42);
    cyl(elec,.045,.045,.3,black,.18,1.48,-.35,Math.PI/2);
    const wire=add(elec,new THREE.TorusGeometry(.25,.018,8,36,Math.PI*1.3),mat(0xd1a34f,.3,.5),-.2,1.36,.16,0,0,.2);wire.scale.set(1,.65,1);
    sphere(elec,.12,.1,.09,lamp,0,1.62,1.31);sphere(elec,.09,.07,.07,red,0,1.17,-1.27);
    // Cabin / rider interface: seat, handlebar, grips, mirrors, instrument cluster
    const cabin=groups.cabin;
    box(cabin,.32,.12,.58,black,0,1.51,-.55);
    box(cabin,.58,.06,.09,alloy,0,1.83,1.0);
    cyl(cabin,.035,.035,.24,black,-.31,1.81,.98,0,0,Math.PI/2);cyl(cabin,.035,.035,.24,black,.31,1.81,.98,0,0,Math.PI/2);
    box(cabin,.22,.13,.14,black,0,1.91,.84);
    cyl(cabin,.018,.018,.35,alloy,-.28,1.93,.74,.1,0,.55);cyl(cabin,.018,.018,.35,alloy,.28,1.93,.74,.1,0,-.55);
    sphere(cabin,.09,.05,.1,glass,0,1.95,.85);
    marker('powertrain','Engine assembly',.28,1.2,-.2);marker('running','Front disc & fork',.18,.45,1.35);marker('electrical','Battery & ignition',-.22,1.12,-.42);marker('cabin','Rider controls',0,1.93,.88);marker('exterior','Headlamp & body',0,1.62,1.31);
  } else {
    // Car/SUV concept uses distinct assemblies and visible cabin glazing.
    const ex=groups.exterior, pw=groups.powertrain, rg=groups.running, el=groups.electrical, cb=groups.cabin;
    box(ex,2.0,.52,4.25,paint,0,.82,0);box(ex,1.75,.58,2.05,paint,0,1.34,-.25);
    box(ex,1.62,.42,1.72,glass,0,1.39,-.25);box(ex,2.02,.17,.72,paint,0,.95,1.78);box(ex,2.02,.16,.66,paint,0,.93,-1.78);
    box(ex,.48,.13,.08,lamp,-.68,.95,2.12);box(ex,.48,.13,.08,lamp,.68,.95,2.12);box(ex,.42,.14,.08,red,-.68,.91,-2.12);box(ex,.42,.14,.08,red,.68,.91,-2.12);
    [[-.94,1.38],[.94,1.38],[-.94,-1.38],[.94,-1.38]].forEach(([x,z])=>{wheel(rg,x,z,.48);torus(rg,.29,.025,alloy,x,.48,z);});
    box(pw,.78,.62,1.02,steel,-.48,.8,.92);box(pw,.62,.2,.74,alloy,-.48,1.18,.92);cyl(pw,.2,.2,.6,steel,-.48,.8,.45,Math.PI/2);
    box(rg,.12,.68,.14,alloy,-.94,.7,1.38);box(rg,.12,.68,.14,alloy,.94,.7,1.38);cyl(rg,.28,.28,.08,alloy,-.94,.48,1.38,0,0,Math.PI/2);
    box(el,.28,.2,.42,black,-.65,.76,-.55);box(el,.12,.08,.12,red,-.65,.9,-.55);
    box(cb,.65,.12,.55,black,0,1.28,-.82);box(cb,1.35,.1,.12,black,0,1.12,.2);box(cb,.12,.34,.12,alloy,0,1.28,.5);
    marker('powertrain','Engine assembly',-.48,1.12,.9);marker('running','Brake & suspension',.94,.48,1.38);marker('electrical','Battery & wiring',-.65,.9,-.55);marker('cabin','Dashboard & controls',0,1.35,.2);marker('exterior','Lighting & body',.7,.98,2.0);
  }
  const floor = new THREE.Mesh(new THREE.CircleGeometry(bike?3.2:4.8,64),new THREE.MeshStandardMaterial({color:0x243a38,roughness:.92,metalness:.05}));floor.rotation.x=-Math.PI/2;floor.position.y=-.025;floor.receiveShadow=true;scene.add(floor);
  const grid=new THREE.GridHelper(bike?6.5:10,36,0x526a60,0x30433e);grid.position.y=-.012;scene.add(grid);
  // Independent orbit camera: camera presets now change the actual viewpoint, not model rotation.
  let azimuth=.72,elevation=.23,distance=bike?5.5:7.6,targetY=bike?1.02:.78,drag=false,lastX=0,lastY=0,downX=0,downY=0,activeSystem='all',wireframe=false;
  const presets={front:{a:0,e:.1},side:{a:Math.PI/2,e:.12},rear:{a:Math.PI,e:.1},top:{a:.2,e:1.05},threequarter:{a:.72,e:.23}};
  function cameraTo(a,e,d=distance){azimuth=a;elevation=e;distance=d;}
  function applySystem(key){activeSystem=key;Object.entries(groups).forEach(([name,g])=>{g.visible=key==='all'||name===key;g.traverse(o=>{if(o.isMesh&&o.material){o.material.transparent=false;o.material.opacity=1;if(o.material.emissive && o.material.emissive.getHex()===0){} }});});markers.forEach(m=>{m.group.visible=true;m.dot.material.color.set(key==='all'||m.key===key?0xe8b16e:0x8f9d98);m.group.scale.setScalar(key==='all'||m.key===key?1:.82);});document.dispatchEvent(new CustomEvent('automart:system-change',{detail:{system:key}}));}
  function resize(){const w=Math.max(1,canvas.clientWidth),h=Math.max(1,canvas.clientHeight);renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}
  new ResizeObserver(resize).observe(canvas);resize();
  canvas.addEventListener('pointerdown',e=>{drag=true;lastX=downX=e.clientX;lastY=downY=e.clientY;canvas.setPointerCapture(e.pointerId);});
  canvas.addEventListener('pointermove',e=>{if(!drag)return;azimuth-=(e.clientX-lastX)*.008;elevation=Math.max(-.12,Math.min(1.25,elevation+(e.clientY-lastY)*.006));lastX=e.clientX;lastY=e.clientY;});
  const stop=()=>drag=false;canvas.addEventListener('pointerup',stop);canvas.addEventListener('pointercancel',stop);
  canvas.addEventListener('wheel',e=>{e.preventDefault();distance=Math.max(bike?3.3:4.7,Math.min(bike?8.5:11,distance+e.deltaY*.006));},{passive:false});
  const ray=new THREE.Raycaster(),pointer=new THREE.Vector2();
  canvas.addEventListener('click',e=>{if(Math.hypot(e.clientX-downX,e.clientY-downY)>6)return;const r=canvas.getBoundingClientRect();pointer.set(((e.clientX-r.left)/r.width)*2-1,-((e.clientY-r.top)/r.height)*2+1);ray.setFromCamera(pointer,camera);const hit=ray.intersectObjects(markers.map(m=>m.group.children[0]),false)[0];if(hit){const m=markers.find(x=>x.group.children[0]===hit.object);if(m)selectSystem(m.key);}});
  function selectSystem(key){const canonical=key==='mechanical'?'powertrain':key;applySystem(canonical);$$('[data-tour]').forEach(t=>t.classList.toggle('active',t.dataset.tour===key));const focus={exterior:'threequarter',mechanical:'side',powertrain:'side',running:'side',electrical:'rear',cabin:'front'}[key]||'threequarter';const p=presets[focus];cameraTo(p.a,p.e,bike?5.1:7.1);}
  $$('[data-tour]').forEach(b=>b.addEventListener('click',()=>selectSystem(b.dataset.tour)));
  $$('[data-system]').forEach(b=>b.addEventListener('click',()=>{const map={'Engine Parts':'powertrain','Brakes':'running','Suspension':'running','Electrical':'electrical','Lighting':'exterior','Accessories':'cabin'};selectSystem(map[b.dataset.system]||b.dataset.system);}));
  const readout=$('#systemReadout');
  const systemCopy={'all':['Complete platform','All visible assemblies are available. Choose a system marker or filter to focus your inspection.'],'Engine Parts':['Powertrain','Inspect engine, lubrication, intake and driveline references. Confirm engine code and displacement before selecting parts.'],'Brakes':['Braking system','Review brake hardware and check disc/drum type, dimensions and mounting configuration.'],'Suspension':['Suspension system','Inspect fork, shock and wheel-control assemblies. Confirm length, travel and mounting points.'],'Electrical':['Electrical system','Review battery, ignition, charging and lighting components. Confirm voltage and connector layout.'],'Lighting':['Lighting system','Inspect headlamp and signal assemblies. Confirm housing, connector, beam type and trim.'],'Filters':['Filtration system','Research air, oil and fuel filtration. Match dimensions and engine-specific service references.']};
  $$('.system-tab').forEach(button=>button.addEventListener('click',()=>{
    const key=button.dataset.system,copy=systemCopy[key]||systemCopy.all;
    $$('.system-tab').forEach(x=>x.classList.toggle('active',x===button));
    if(readout){const idx=$$('.system-tab').indexOf(button)+1;readout.innerHTML=`<span class="readout-index">SYS / ${String(idx).padStart(2,'0')}</span><div><strong>${copy[0]}</strong><p>${copy[1]}</p></div><span class="readout-status">REFERENCE DATA</span>`;}
    const grid=$('#partsGrid');if(grid)$$('[data-category]',grid).forEach(card=>{card.hidden=key!=='all'&&!card.dataset.category.toLowerCase().includes(key.toLowerCase());});
    const map={'Engine Parts':'powertrain','Brakes':'running','Suspension':'running','Electrical':'electrical','Lighting':'exterior','Filters':'powertrain'};selectSystem(map[key]||'all');
  }));
  $$('.camera-preset').forEach(b=>b.addEventListener('click',()=>{const p=presets[b.dataset.camera];if(!p)return;cameraTo(p.a,p.e,bike?5.5:7.6);$$('.camera-preset').forEach(x=>x.classList.toggle('active',x===b));}));
  const reset=$('#resetVehicle');if(reset)reset.addEventListener('click',()=>{cameraTo(presets.threequarter.a,presets.threequarter.e,bike?5.5:7.6);applySystem(document.body.classList.contains('theme-tour')?activeSystem:'all');$$('.camera-preset').forEach(x=>x.classList.toggle('active',x.dataset.camera==='threequarter'));});
  $$('.studio-mode').forEach(b=>b.addEventListener('click',()=>{wireframe=b.dataset.view==='wireframe';vehicle.traverse(o=>{if(o.isMesh&&o.material)o.material.wireframe=wireframe;});$$('.studio-mode').forEach(x=>x.classList.toggle('active',x===b));}));
  const zoomIn=$('#studioZoomIn'),zoomOut=$('#studioZoomOut');if(zoomIn)zoomIn.addEventListener('click',()=>distance=Math.max(bike?3.3:4.7,distance*.88));if(zoomOut)zoomOut.addEventListener('click',()=>distance=Math.min(bike?8.5:11,distance*1.14));
  let raf=0;function render(){raf=requestAnimationFrame(render);const x=Math.cos(elevation)*Math.sin(azimuth)*distance,z=Math.cos(elevation)*Math.cos(azimuth)*distance,y=Math.sin(elevation)*distance;camera.position.set(x,targetY+y,z);camera.lookAt(0,targetY,0);if(!reduceMotion)markers.forEach((m,i)=>{m.group.children[0].scale.setScalar(1+Math.sin(performance.now()*.002+i)*.1);});renderer.render(scene,camera);}render();
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&raf)cancelAnimationFrame(raf);else if(!document.hidden)render();});
  const full=$('#studioFullscreen');if(full)full.addEventListener('click',()=>{const stage=canvas.closest('.tour-model-stage');if(!document.fullscreenElement)stage?.requestFullscreen?.();else document.exitFullscreen?.();});
  window.AutoMartStudio={selectSystem,reset:()=>{cameraTo(presets.threequarter.a,presets.threequarter.e,bike?5.5:7.6);applySystem(document.body.classList.contains('theme-tour')?activeSystem:'all');},setCamera:key=>{if(presets[key]){cameraTo(presets[key].a,presets[key].e);$$('.camera-preset').forEach(b=>b.classList.toggle('active',b.dataset.camera===key));}}};
  applySystem('all');
})();
