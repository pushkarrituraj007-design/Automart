(() => {
  const input=document.getElementById('vehicleDirectorySearch');
  const make=document.getElementById('vehicleMakeFilter');
  const grid=document.getElementById('vehicleDirectoryGrid');
  const count=document.getElementById('vehicleResultCount');
  const empty=document.getElementById('vehicleNoResults');
  if(!grid)return;
  const cards=[...grid.querySelectorAll('.vehicle-v3-card')];
  const apply=()=>{
    const term=(input?.value||'').trim().toLowerCase();
    const selected=make?.value||'all';
    cards.forEach(card=>{const okText=(card.dataset.search||'').includes(term);const okMake=selected==='all'||card.dataset.make===selected;card.hidden=!(okText&&okMake)});
    const visible=cards.filter(c=>!c.hidden).length;
    if(count)count.textContent=`${visible} vehicle ${visible===1?'record':'records'}`;
    if(empty)empty.hidden=visible!==0;
  };
  input?.addEventListener('input',apply);make?.addEventListener('change',apply);apply();
})();
