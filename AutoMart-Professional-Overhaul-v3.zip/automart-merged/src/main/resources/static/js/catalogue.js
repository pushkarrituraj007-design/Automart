(() => {
  const sort=document.getElementById('catalogSort'),grid=document.getElementById('catalogGrid'),count=document.getElementById('catalogVisibleCount');
  if(!grid)return;
  const cards=[...grid.querySelectorAll('.catalog-result')],order=new Map(cards.map((card,index)=>[card,index]));
  const apply=()=>{
    const mode=sort?.value||'relevance';
    const ordered=[...cards].sort((a,b)=>{
      if(mode==='name')return(a.dataset.name||'').localeCompare(b.dataset.name||'');
      if(mode==='brand')return(a.dataset.brand||'').localeCompare(b.dataset.brand||'');
      if(mode==='part')return(a.dataset.part||'').localeCompare(b.dataset.part||'');
      return order.get(a)-order.get(b);
    });
    ordered.forEach(card=>grid.appendChild(card));
    if(count)count.textContent=String(cards.length);
  };
  sort?.addEventListener('change',apply);apply();
})();