(() => {const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;if(!reduced&&'IntersectionObserver'in window){const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target)}}),{threshold:.1});$$('.reveal,.reveal-x,.reveal-y').forEach(el=>io.observe(el));} $$('.h-scroll').forEach(rail=>rail.addEventListener('wheel',e=>{if(Math.abs(e.deltaY)>Math.abs(e.deltaX)){rail.scrollLeft+=e.deltaY;e.preventDefault()}},{passive:false}));const key='automart.shortlist.v1',read=()=>{try{return JSON.parse(localStorage.getItem(key)||'[]')}catch{return[]}},write=a=>localStorage.setItem(key,JSON.stringify(a));const render=()=>{const host=$('#shortlist-items');if(!host)return;const ids=read();host.innerHTML=ids.length?ids.map(id=>`<span class="shortlist-chip">Part #${String(id).replace(/[^0-9]/g,'')} <button type="button" data-remove="${String(id).replace(/[^0-9]/g,'')}" aria-label="Remove saved part">×</button></span>`).join(''):'<span class="text-white-50">No saved parts yet. Save a catalogue reference using the bookmark control.</span>';};document.addEventListener('click',e=>{const b=e.target.closest('.save-part');if(b){const id=b.dataset.productId,a=read(),has=a.includes(id);write(has?a.filter(x=>x!==id):[...a,id]);b.classList.toggle('is-saved',!has);b.textContent=has?'♡':'♥';render()}const rm=e.target.closest('[data-remove]');if(rm){write(read().filter(x=>x!==rm.dataset.remove));render()}});$$('.save-part').forEach(b=>{if(read().includes(b.dataset.productId)){b.classList.add('is-saved');b.textContent='♥'}});render();
  // Spatial scroll choreography: reveal meaningful sections and stagger repeated cards.
  const main=document.querySelector('main');
  if(main){
    const revealTargets=[...main.querySelectorAll(':scope > section, :scope > .container > section, .home-section, .directory-heading, .product-card, .system-directory-card, .vehicle-index-card, .entry-card, .tour-reference-strip, .tour-bottom-cta')];
    revealTargets.forEach((el,i)=>{
      if(el.closest('.tour-inspector-v2')||el.matches('[data-no-reveal]'))return;
      el.setAttribute('data-reveal',el.matches('.product-card,.system-directory-card,.vehicle-index-card,.entry-card')?'scale':'up');
      if(el.matches('.product-card,.system-directory-card,.vehicle-index-card,.entry-card'))el.style.setProperty('--reveal-delay',`${(i%4)*65}ms`);
    });
    if(reduced)revealTargets.forEach(el=>el.classList.add('is-visible'));
    else if('IntersectionObserver'in window){
      const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{
        if(entry.isIntersecting){entry.target.classList.add('is-visible');revealObserver.unobserve(entry.target);}
      }),{threshold:.08,rootMargin:'0px 0px -45px 0px'});
      revealTargets.forEach(el=>revealObserver.observe(el));
    }else revealTargets.forEach(el=>el.classList.add('is-visible'));
  }
})();