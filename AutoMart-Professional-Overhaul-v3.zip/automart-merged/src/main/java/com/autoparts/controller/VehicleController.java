package com.autoparts.controller;

import com.autoparts.model.Vehicle;
import com.autoparts.repository.ProductRepository;
import com.autoparts.repository.CategoryRepository;
import com.autoparts.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class VehicleController {

    @Autowired private VehicleRepository vehicleRepository;
    @Autowired private ProductRepository productRepository;
    @Autowired private CategoryRepository categoryRepository;

    @GetMapping("/vehicles")
    public String list(Model model) {
        var vehicles = vehicleRepository.findAll();
        model.addAttribute("vehicles", vehicles);
        model.addAttribute("makes", vehicles.stream().map(Vehicle::getMake).filter(java.util.Objects::nonNull).distinct().sorted().toList());
        return "vehicles";
    }

    @GetMapping("/vehicles/{id}/tour")
    public String tour(@PathVariable Long id, Model model) {
        Vehicle vehicle = vehicleRepository.findById(id).orElseThrow();
        model.addAttribute("vehicle", vehicle);
        return "vehicle-tour";
    }

    @GetMapping("/vehicles/{id}")
    public String detail(@PathVariable Long id, Model model) {
        Vehicle vehicle = vehicleRepository.findById(id).orElseThrow();
        model.addAttribute("vehicle", vehicle);
        model.addAttribute("parts", productRepository.findByVehicleId(id));
        model.addAttribute("categories", categoryRepository.findAll());
        return "vehicle-detail";
    }
}
