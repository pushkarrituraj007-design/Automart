package com.autoparts.controller;

import com.autoparts.model.Brand;
import com.autoparts.model.Category;
import com.autoparts.model.Product;
import com.autoparts.repository.BrandRepository;
import com.autoparts.repository.CategoryRepository;
import com.autoparts.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import com.autoparts.service.CatalogueService;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.stream.Collectors;

@Controller
public class ProductController {

    @Autowired private ProductRepository productRepository;
    @Autowired private CategoryRepository categoryRepository;
    @Autowired private BrandRepository brandRepository;
    @Autowired private CatalogueService catalogueService;

    @GetMapping("/products")
    public String search(@RequestParam(required = false) String keyword, Model model) {
        List<Product> result;
        String title;
        if (keyword == null || keyword.isBlank()) {
            result = catalogueService.all();
            title = "All Parts";
        } else {
            result = catalogueService.search(keyword);
            title = "Results for \"" + keyword.trim() + "\"";
        }
        model.addAttribute("products", result);
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("selectedCategory", null);
        model.addAttribute("title", title);
        model.addAttribute("subtitle", result.size() + " parts found");
        model.addAttribute("keyword", keyword);
        model.addAttribute("theme", "theme-shop");
        return "products";
    }

    @GetMapping("/category/{id}")
    public String byCategory(@PathVariable Long id, Model model) {
        Category category = categoryRepository.findById(id).orElseThrow();
        List<Product> list = productRepository.findByCategoryId(id);
        model.addAttribute("category", category);
        model.addAttribute("products", list);
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("selectedCategory", id);
        model.addAttribute("title", category.getName());
        model.addAttribute("subtitle", list.size() + " parts in this category");
        model.addAttribute("theme", "theme-categories");
        return "products";
    }

    @GetMapping("/brand/{id}")
    public String byBrand(@PathVariable Long id, Model model) {
        Brand brand = brandRepository.findById(id).orElseThrow();
        List<Product> list = productRepository.findByBrandId(id);
        model.addAttribute("brand", brand);
        model.addAttribute("products", list);
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("selectedCategory", null);
        model.addAttribute("title", brand.getName());
        model.addAttribute("subtitle", brand.getTagline() + " - " + list.size() + " products");
        model.addAttribute("theme", "theme-brands");
        return "products";
    }

    @GetMapping("/products/{id}")
    public String detail(@PathVariable Long id, Model model) {
        Product product = productRepository.findById(id).orElseThrow();
        List<Product> related = List.of();
        if (product.getCategory() != null) {
            related = productRepository.findByCategoryId(product.getCategory().getId()).stream()
                    .filter(p -> !p.getId().equals(product.getId()))
                    .limit(4)
                    .collect(Collectors.toList());
        }
        model.addAttribute("product", product);
        model.addAttribute("related", related);
        return "product-detail";
    }

}
