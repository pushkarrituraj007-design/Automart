package com.autoparts.config;

import com.autoparts.model.*;
import com.autoparts.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class DataSeeder implements CommandLineRunner {

    @Autowired private ProductRepository productRepository;
    @Autowired private CategoryRepository categoryRepository;
    @Autowired private BrandRepository brandRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private VehicleRepository vehicleRepository;

    private final Map<String, String> catColor = new HashMap<>();

    @Override
    public void run(String... args) {
        if (productRepository.count() > 0) {
            refreshReferenceImages();
            return;
        }

        seedUsers();
        Map<String, Brand> brands = seedBrands();
        Map<String, Category> cats = seedCategories();
        seedGenericProducts(brands, cats);
        seedVehiclesAndParts(brands, cats);
        seedMotorcycles(brands, cats);
    }


    /** Refreshes reference-image mappings on existing demo rows too; previously the
     * early-return left stale/broken photos in place after a code update. */
    private void refreshReferenceImages() {
        for (Category c : categoryRepository.findAll()) {
            c.setImageUrl(photoFor(c.getName()));
            categoryRepository.save(c);
        }
        for (Product p : productRepository.findAll()) {
            if (p.getCategory() != null) p.setImageUrl(photoFor(p.getCategory().getName()));
            productRepository.save(p);
        }
        for (Vehicle v : vehicleRepository.findAll()) {
            v.setImageUrl(vehiclePhoto(v.getMake(), v.getModel()));
            vehicleRepository.save(v);
        }
    }

    private void seedUsers() {
        User admin = new User();
        admin.setName("Admin");
        admin.setEmail("admin@autoparts.com");
        admin.setPassword("admin123");
        admin.setRole("ADMIN");
        userRepository.save(admin);

        User demo = new User();
        demo.setName("Demo Customer");
        demo.setEmail("demo@autoparts.com");
        demo.setPassword("demo123");
        demo.setRole("CUSTOMER");
        userRepository.save(demo);
    }

    private Map<String, Brand> seedBrands() {
        String[][] data = {
            {"Exide", "https://www.exideindustries.com", "Batteries & Power"},
            {"Amaron", "https://www.amaron.in", "Long-life Batteries"},
            {"MRF", "https://www.mrftyres.com", "Tyres"},
            {"Apollo", "https://www.apollotyres.com", "Tyres"},
            {"CEAT", "https://www.ceat.com", "Tyres"},
            {"JK Tyre", "https://www.jktyre.com", "Tyres"},
            {"Uno Minda", "https://www.unominda.com", "Switches, Lamps & Filters"},
            {"Lucas-TVS", "https://www.lucastvs.com", "Electricals"},
            {"Rane", "https://www.rane.co.in", "Brakes & Steering"},
            {"Gabriel", "https://www.gabriel.co.in", "Shock Absorbers"},
            {"Varroc", "https://www.varroc.com", "Lighting"},
            {"Lumax", "https://www.lumaxworld.in", "Lighting & Accessories"},
            {"Endurance", "https://www.endurancegroup.com", "Suspension & Braking"},
            {"Castrol India", "https://www.castrol.com/en_in/india/home.html", "Engine Oils"},
            {"Hero MotoCorp", "https://www.heromotocorp.com/", "Motorcycles & Genuine Parts"},
            {"Honda", "https://www.honda2wheelersindia.com/", "Motorcycles & Scooters"},
            {"Royal Enfield", "https://www.royalenfield.com/in/en/home/", "Motorcycles & Genuine Parts"},
            {"TVS", "https://www.tvsmotor.com/", "Motorcycles & Scooters"}
        };
        Map<String, Brand> map = new HashMap<>();
        for (String[] r : data) {
            Brand b = new Brand();
            b.setName(r[0]);
            b.setWebsiteUrl(r[1]);
            b.setTagline(r[2]);
            map.put(r[0], brandRepository.save(b));
        }
        return map;
    }

    private Map<String, Category> seedCategories() {
        String[][] data = {
            {"Engine Parts", "🔧", "1e3a8a"},
            {"Brakes", "🛑", "991b1b"},
            {"Suspension", "🔩", "7c2d12"},
            {"Electrical", "⚡", "a16207"},
            {"Batteries", "🔋", "166534"},
            {"Tyres", "🛞", "1f2937"},
            {"Lighting", "💡", "0e7490"},
            {"Lubricants", "🛢️", "b45309"},
            {"Filters", "🌀", "4338ca"},
            {"Accessories", "🎛️", "be185d"},
            {"Drivetrain", "⚙️", "334155"}
        };
        Map<String, Category> map = new HashMap<>();
        for (String[] r : data) {
            Category c = new Category();
            c.setName(r[0]);
            c.setIcon(r[1]);
            c.setImageUrl(photoFor(r[0]));
            catColor.put(r[0], r[2]);
            map.put(r[0], categoryRepository.save(c));
        }
        return map;
    }

    private void seedGenericProducts(Map<String, Brand> brands, Map<String, Category> cats) {
        String[][] rows = {
            {"Exide Mileage ML65 Car Battery 65Ah", "Batteries", "Exide", "6499","Automotive battery reference with a stated 65Ah capacity. Confirm case size, terminal layout, polarity and vehicle electrical requirements before ordering."},
            {"Exide Xplore 9Ah Bike Battery", "Batteries", "Exide", "1449","Two-wheeler battery reference with a stated 9Ah capacity. Match dimensions, terminal orientation and the manufacturer's fitment code."},
            {"Amaron Pro 55Ah Car Battery", "Batteries", "Amaron", "5799","Automotive battery reference with a stated 55Ah capacity. Check tray dimensions, terminal polarity and required cranking specification."},
            {"Amaron Hi-Life Pro 35Ah Battery", "Batteries", "Amaron", "3999","Compact-vehicle battery reference with a stated 35Ah capacity. Confirm the case code, terminal layout and vehicle requirement."},
            {"MRF ZVTV 185/65 R15 Tubeless Tyre", "Tyres", "MRF", "4850","Tubeless passenger-car tyre reference. Size listed: 185/65 R15; verify load index, speed rating and approved fitment."},
            {"MRF Revz-C 100/90-17 Bike Tyre", "Tyres", "MRF", "2299","Motorcycle tyre reference. Size listed: 100/90-17; confirm front/rear position, construction and rim compatibility."},
            {"Apollo Amazer 4G Life 165/80 R14", "Tyres", "Apollo", "3999","Passenger-car tyre reference. Size listed: 165/80 R14; check load and speed ratings against the vehicle placard."},
            {"Apollo Alnac 4G 205/55 R16", "Tyres", "Apollo", "6150","Passenger-car tyre reference. Size listed: 205/55 R16; verify approved size, load index and speed rating."},
            {"CEAT SecuraDrive 185/65 R15", "Tyres", "CEAT", "4250","Passenger-car tyre reference. Size listed: 185/65 R15; confirm the vehicle-approved tyre specification before purchase."},
            {"CEAT Zoom Plus 90/90-17 Bike Tyre", "Tyres", "CEAT", "1899","Motorcycle tyre reference. Size listed: 90/90-17; verify wheel position, rim size and approved load/speed rating."},
            {"JK Tyre UX Royale 195/65 R15", "Tyres", "JK Tyre", "4650","Passenger-car tyre reference. Size listed: 195/65 R15; check the vehicle placard for approved dimensions and ratings."},
            {"JK Tyre Elanzo Touring 175/65 R14", "Tyres", "JK Tyre", "3790","Passenger-car tyre reference. Size listed: 175/65 R14; confirm the exact size and load/speed rating for the vehicle."},
            {"Rane Front Brake Lining Set", "Brakes", "Rane", "1250","Front brake friction-component reference. Confirm whether the vehicle uses the matching brake assembly and check the exact part code."},
            {"Uno Minda Ventilated Brake Disc Rotor", "Brakes", "Uno Minda", "2150","Ventilated brake-disc reference. Match disc diameter, thickness, height, bolt pattern and axle position."},
            {"Endurance Front Disc Brake Caliper", "Brakes", "Endurance", "3850","Front disc-brake caliper reference. Verify mounting points, piston configuration and left/right application."},
            {"Rane Brake Shoe Set Rear Drum", "Brakes", "Rane", "980","Rear drum-brake shoe reference. Match drum diameter, shoe width, spring arrangement and vehicle application."},
            {"Gabriel Gas Shock Absorber Front", "Suspension", "Gabriel", "2899","Gas-charged front shock absorber reference. Confirm mounting type, extended length and vehicle-specific damping application."},
            {"Gabriel Ultra Rear Shock Absorber", "Suspension", "Gabriel", "2450","Rear shock absorber reference. Check eye-to-eye length, mounting bush dimensions and spring specification for the exact model."},
            {"Rane Steering Tie Rod End", "Suspension", "Rane", "780","Steering tie-rod end reference. Verify thread, taper, handedness and steering geometry for the vehicle."},
            {"Endurance Front Fork Assembly Bike", "Suspension", "Endurance", "5400","Motorcycle front-fork assembly reference. Confirm fork length, diameter, axle mount and model-year compatibility."},
            {"Lucas-TVS Alternator 12V 90A", "Electrical", "Lucas-TVS", "7800","12V alternator reference with a stated 90A output. Match mounting, pulley, connector and regulator configuration."},
            {"Lucas-TVS Starter Motor 12V", "Electrical", "Lucas-TVS", "6200","12V starter-motor reference. Check mounting pattern, pinion engagement and electrical connector before ordering."},
            {"Uno Minda Twin Tone Horn Set", "Electrical", "Uno Minda", "899","Twin-tone horn-set reference. Confirm voltage, current draw, mounting space and connector compatibility."},
            {"Lucas-TVS Ignition Coil", "Electrical", "Lucas-TVS", "1450","Ignition-coil reference. Match primary/secondary specification, connector and engine application."},
            {"Rane Engine Valve Set", "Engine Parts", "Rane", "3200","Engine-valve set reference. Confirm intake/exhaust position, stem dimensions and engine code."},
            {"Uno Minda Spark Plug Set of 4", "Engine Parts", "Uno Minda", "799","Four-piece spark-plug listing. Verify thread diameter, reach, heat range and electrode specification against the engine."},
            {"Rane Timing Chain Tensioner", "Engine Parts", "Rane", "1850","Timing-chain tensioner reference. Match the engine code, mounting pattern and tensioner revision."},
            {"Lumax Cygnus LED Headlight Bulb H4", "Lighting", "Lumax", "1599","H4 LED headlamp-bulb reference. Confirm H4 socket, beam compatibility, available clearance and local road-use requirements."},
            {"Varroc LED Tail Lamp Assembly", "Lighting", "Varroc", "3499","LED rear-lamp assembly reference. Match body shape, connector, mounting points and exact vehicle variant."},
            {"Uno Minda Fog Lamp Kit", "Lighting", "Uno Minda", "2299","Fog-lamp kit reference. Check lamp dimensions, mounting brackets, wiring and vehicle-specific installation requirements."},
            {"Lumax LED Indicator Set Bike", "Lighting", "Lumax", "599","Motorcycle LED indicator-set reference. Confirm mounting thread, connector, voltage and indicator relay compatibility."},
            {"Varroc Projector Headlamp Unit", "Lighting", "Varroc", "5200","Projector headlamp-unit reference. Verify housing shape, beam orientation, connectors and vehicle trim."},
            {"Castrol MAGNATEC 5W-30 3.5L", "Lubricants", "Castrol India", "2799","Engine-oil listing: 5W-30, 3.5L. Check the owner's manual for the required viscosity and manufacturer approval."},
            {"Castrol GTX 20W-40 3.5L", "Lubricants", "Castrol India", "1899","Engine-oil listing: 20W-40, 3.5L. Use only where the vehicle manufacturer specifies the matching viscosity and performance standard."},
            {"Castrol ACTIV 4T 10W-30 1L Bike", "Lubricants", "Castrol India", "449","Four-stroke motorcycle-oil listing: 10W-30, 1L. Confirm the required JASO/API specification and wet-clutch compatibility."},
            {"Castrol Brake Fluid DOT 4 500ml", "Lubricants", "Castrol India", "399","Brake-fluid listing: DOT 4, 500ml. Use only the fluid specification printed in the vehicle handbook or reservoir cap."},
            {"Uno Minda Air Filter Element", "Filters", "Uno Minda", "549","Engine air-filter element reference. Match the filter shape, dimensions and engine application before fitting."},
            {"Lucas-TVS Oil Filter Spin-On", "Filters", "Lucas-TVS", "299","Spin-on oil-filter reference. Verify thread, gasket diameter, bypass specification and engine application."},
            {"Uno Minda Cabin AC Filter", "Filters", "Uno Minda", "449","Cabin air-filter reference. Check dimensions, airflow direction and whether the vehicle uses a standard or carbon filter."},
            {"Uno Minda 12V Tyre Inflator", "Accessories", "Uno Minda", "1899","12V tyre-inflator accessory reference. Check vehicle socket capacity, hose connection and pressure range before use."},
            {"Lumax Leather Gear Shift Knob", "Accessories", "Lumax", "699","Gear-shift knob accessory reference. Confirm shaft diameter, thread/retainer type and transmission layout."},
            {"Varroc Side Rear View Mirror Pair", "Accessories", "Varroc", "1299","Exterior mirror-pair reference. Match mounting points, adjustment type, connector and vehicle side/variant."}
        };
        for (String[] r : rows) {
            saveProduct(r[0], r[4], Double.parseDouble(r[3]), cats.get(r[1]), brands.get(r[2]), null, "Universal");
        }
    }

    private void seedVehiclesAndParts(Map<String, Brand> brands, Map<String, Category> cats) {
        String[][] vehicles = {
            {"Maruti Suzuki", "Swift", "2005 - Present", "India's favourite sporty hatchback, loved for its zippy engine, sharp handling and low running costs.", "1.0", "b91c1c"},
            {"Hyundai", "Creta", "2015 - Present", "A feature-packed compact SUV with a premium cabin, strong road presence and flexible engine choices.", "1.35", "1d4ed8"},
            {"Tata", "Nexon", "2017 - Present", "India's safety-first compact SUV with a 5-star crash rating and bold, modern styling.", "1.25", "0f766e"},
            {"Honda", "City", "1998 - Present", "The benchmark premium sedan, known for refinement, reliability and a spacious, comfortable cabin.", "1.3", "475569"},
            {"Mahindra", "Scorpio-N", "2022 - Present", "A rugged, commanding full-size SUV built for highways, hills and everything in between.", "1.6", "111827"}
        };
        String[][] parts = {
            {"Front Brake Pad Set", "Brakes", "Rane", "1450", "Low-dust, low-noise friction material for consistent stopping."},
            {"Air Filter", "Filters", "Uno Minda", "520", "High-flow filter that protects the engine and helps fuel economy."},
            {"Oil Filter", "Filters", "Lucas-TVS", "320", "Keeps engine oil clean for longer engine life."},
            {"Front Shock Absorber", "Suspension", "Gabriel", "3200", "Gas-charged shock for a stable, comfortable ride."},
            {"LED Headlight Bulb", "Lighting", "Lumax", "1800", "Bright LED bulb for better visibility on dark roads."},
            {"Engine Oil 5W-30 3.5L", "Lubricants", "Castrol India", "2700", "Synthetic-blend oil for smooth, protected performance."},
            {"Car Battery", "Batteries", "Exide", "6200", "Maintenance-free battery with strong cranking power."},
            {"Tubeless Tyre", "Tyres", "MRF", "4800", "Durable tyre with confident grip in dry and wet conditions."}
        };
        for (String[] v : vehicles) {
            Vehicle ve = new Vehicle();
            ve.setMake(v[0]);
            ve.setModel(v[1]);
            ve.setYearRange(v[2]);
            ve.setDescription(v[3]);
            ve.setImageUrl(vehiclePhoto(v[0], v[1]));
            ve = vehicleRepository.save(ve);

            double factor = Double.parseDouble(v[4]);
            for (String[] t : parts) {
                double price = Math.round(Double.parseDouble(t[3]) * factor / 10.0) * 10.0;
                String name = t[2] + " " + t[0] + " for " + v[1];
                String desc = t[4] + " Application shown for research only. Confirm exact generation, variant, engine and manufacturer part number before purchase.";
                saveProduct(name, desc, price, cats.get(t[1]), brands.get(t[2]), ve, v[0] + " " + v[1]);
            }
        }
    }

    private void saveProduct(String name, String desc, double price, Category c, Brand b, Vehicle v, String compat) {
        Product p = new Product();
        p.setName(name);
        p.setDescription(desc);
        p.setPrice(null); // No fabricated or stale retail pricing in a referral catalogue.
        p.setMrp(null);
        p.setStock(0); // discovery-only catalogue: inventory is not sold or represented as live
        p.setRating(null);
        p.setRatingCount(0);
        p.setPartNumber("Check manufacturer catalogue");
        p.setListingType("BRAND-CATALOGUE");
        p.setFitmentNote("Compatibility is indicative only. Confirm the exact part number, variant, year and engine with the manufacturer or authorised seller before purchase.");
        p.setImageUrl(photoFor(c.getName()));
        // Only show the category reference image until an exact SKU image is supplied.
        // Do not fabricate a multi-angle gallery from unrelated category photographs.
        p.setGalleryImages("");
        p.setOfficialLink(b.getWebsiteUrl());
        p.setCompatibleModels(compat);
        p.setCategory(c);
        p.setBrand(b);
        p.setVehicle(v);
        productRepository.save(p);
    }

    private void seedMotorcycles(Map<String, Brand> brands, Map<String, Category> cats) {
        String[][] bikes = {
            {"Hero MotoCorp", "Splendor Plus", "2005 - Present", "Everyday commuter motorcycle platform. Confirm exact generation, variant and engine before selecting parts."},
            {"Honda", "Activa 6G", "2020 - Present", "Popular automatic scooter platform. Confirm model year and trim for service components."},
            {"Royal Enfield", "Classic 350", "2021 - Present", "Modern J-series retro roadster platform. Confirm model generation and ABS variant."},
            {"TVS", "Apache RTR 160", "2007 - Present", "Sport commuter motorcycle family. Confirm exact displacement, generation and variant."}
        };
        String[][] parts = {
            {"Engine Oil 4T", "Lubricants", "Castrol India", "Motorcycle-specific lubricant; match viscosity and JASO/API specification to the owner's manual."},
            {"Front Brake Pad Set", "Brakes", "Endurance", "Brake friction component; confirm caliper type, year and exact part code."},
            {"Air Filter Element", "Filters", "Uno Minda", "Engine intake filter; confirm dimensions and exact vehicle variant."},
            {"Battery Assembly", "Batteries", "Exide", "Starting battery; verify voltage, capacity, polarity and case dimensions."},
            {"Chain & Sprocket Kit", "Drivetrain", "Endurance", "Final-drive wear kit; confirm tooth count, pitch and chain length."},
            {"Rear Shock Absorber", "Suspension", "Gabriel", "Suspension component; verify mounting points and vehicle-specific application."},
            {"LED Headlamp Assembly", "Lighting", "Lumax", "Lighting assembly; check connector, beam pattern and road-legal approval."}
        };
        for (String[] b : bikes) {
            Vehicle v = new Vehicle(); v.setMake(b[0]); v.setModel(b[1]); v.setYearRange(b[2]); v.setDescription(b[3]); v.setImageUrl(vehiclePhoto(b[0], b[1])); v = vehicleRepository.save(v);
            for (String[] item : parts) {
                saveProduct(b[0] + " " + b[1] + " — " + item[0], item[3], 0, cats.get(item[1]), brands.get(item[2]), v, b[0] + " " + b[1]);
            }
        }
    }

    private String vehiclePhoto(String make, String model) {
        String key = (make + " " + model).toLowerCase();
        // Editorial vehicle imagery is intentionally labelled as non-exact-trim photography in the UI.
        if (key.contains("splendor")) return "https://www.heromotocorp.com/en-in/motorcycles/practical/media_1351a67f39f393e27e5d372ebed3ad5b147eb3cf3.avif?width=2000&format=webply&optimize=medium";
        if (key.contains("activa")) return "https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=1400&q=88";
        if (key.contains("classic 350")) return "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=1400&q=88";
        if (key.contains("apache")) return "https://images.unsplash.com/photo-1558981420-87aa9dad1c17?auto=format&fit=crop&w=1400&q=88";
        // Distinct editorial reference photographs by model. These are not exact-trim images.
        if (key.contains("swift")) return "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1400&q=88";
        if (key.contains("creta")) return "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=1400&q=88";
        if (key.contains("nexon")) return "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1400&q=88";
        if (key.contains("city")) return "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1400&q=88";
        if (key.contains("scorpio")) return "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=1400&q=88";
        if (key.contains("splendor")) return "https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=1400&q=88";
        if (key.contains("activa")) return "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=1400&q=88";
        if (key.contains("classic 350")) return "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=1400&q=88";
        return "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1400&q=88";
    }

    // Category-level images are deliberately not presented as exact SKU photographs.
    private String photoFor(String category) {
        return switch (category) {
            case "Batteries" -> "https://images.unsplash.com/photo-1606577924006-27d39b132ae2?auto=format&fit=crop&w=1000&q=85";
            case "Tyres" -> "https://shop.shibatire.com/cdn/shop/files/R02_7abf88f7-0a46-4e6b-ab71-90bb4f1df5de.jpg?v=1724234373&width=1946";
            case "Brakes" -> "https://www.kingpartswarehouse.com.au/cdn/shop/collections/brake-pad-and-disc-rotor.png?v=1758623869&width=1500";
            case "Suspension" -> "https://static.winparts.net/drivetrain-suspension/shock-absorbers-coil-springs/shock-absorbers/c10/shock-absorber-monroe-original-gas-technology-g7306/p4355298_900_900.jpg";
            case "Lubricants" -> "https://cdn.salla.sa/GYRwqj/6ca2a13a-1f88-4663-8720-8c455ecd1a05-500x500-NUYZ9KwgOsqgI26TD13Uc0ifbs4ZlTKhHRER3eAK.png";
            case "Electrical" -> "https://www.magnetimarelli-parts-and-services.pt/news/2018/news/catalogo-alternadores-e-motores-de-arranque/_jcr_content/root/enh_responsivegrid/mm_container/par_0/twovariantscolumn/par_0/image.coreimg.jpeg/1714663683362/alternatori-e-motori-avviamento.jpeg";
            case "Filters" -> "https://res.cloudinary.com/knfilters-com/image/upload/c_lpad,dpr_2.0,f_auto,q_auto/v1/media/wysiwyg/p/a/panel-and-round-filter.jpg";
            case "Lighting" -> "https://images.unsplash.com/photo-1504215680853-026ed2a45def?auto=format&fit=crop&w=1000&q=85";
            case "Engine Parts" -> "https://images.unsplash.com/photo-1487754180451-c456f719a1fc?auto=format&fit=crop&w=1000&q=85";
            case "Drivetrain" -> "https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?auto=format&fit=crop&w=1000&q=85";
            default -> "https://images.unsplash.com/photo-1487754180451-c456f719a1fc?auto=format&fit=crop&w=1000&q=85";
        };
    }

    private String img(int w, int h, String hex, String text) {
        String t = text.replaceAll("[^A-Za-z0-9 ]", " ").trim().replaceAll("\\s+", "+");
        return "https://placehold.co/" + w + "x" + h + "/" + hex + "/ffffff?text=" + t;
    }
}
