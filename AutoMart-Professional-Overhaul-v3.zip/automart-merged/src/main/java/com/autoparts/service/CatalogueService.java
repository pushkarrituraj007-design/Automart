package com.autoparts.service;

import com.autoparts.model.Product;
import com.autoparts.repository.ProductRepository;
import org.springframework.stereotype.Service;
import java.util.*;

/** Relevance-first catalogue matching. Generic marketing descriptions are deliberately
 * excluded so a broad word such as "engine" cannot match unrelated products. */
@Service
public class CatalogueService {
    private final ProductRepository products;
    public CatalogueService(ProductRepository products) { this.products = products; }

    public List<Product> all() {
        return products.findAll().stream().sorted(Comparator.comparing(p -> safe(p.getName()))).toList();
    }

    public List<Product> search(String query) {
        if (query == null || query.isBlank()) return all();
        String term = normalize(query);
        List<String> tokens = Arrays.stream(term.split("\\s+")).filter(s -> s.length() > 1).toList();
        return products.findAll().stream()
            .map(p -> Map.entry(p, score(p, term, tokens)))
            .filter(e -> e.getValue() > 0)
            .sorted(Map.Entry.<Product,Integer>comparingByValue().reversed()
                .thenComparing(e -> safe(e.getKey().getName())))
            .map(Map.Entry::getKey).toList();
    }

    private int score(Product p, String term, List<String> tokens) {
        String name = normalize(p.getName());
        String part = normalize(p.getPartNumber());
        String brand = p.getBrand() == null ? "" : normalize(p.getBrand().getName());
        String category = p.getCategory() == null ? "" : normalize(p.getCategory().getName());
        String vehicle = p.getVehicle() == null ? "" : normalize(p.getVehicle().getMake()+" "+p.getVehicle().getModel());
        String compatible = normalize(p.getCompatibleModels());
        if (name.equals(term) || part.equals(term)) return 100;
        if (part.contains(term) && !term.isBlank()) return 95;
        if (name.contains(term)) return 85;
        if (brand.contains(term)) return 70;
        if (category.equals(term)) return 65;
        if (category.contains(term)) return 60;
        if (vehicle.contains(term) || compatible.contains(term)) return 55;
        // Multiword queries must match all meaningful tokens in identity fields.
        if (tokens.size() > 1) {
            int matched = 0;
            for (String token : tokens) if (name.contains(token) || part.contains(token) || brand.contains(token) || category.contains(token)) matched++;
            if (matched == tokens.size()) return 40 + matched;
        }
        return 0;
    }
    private String normalize(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim(); }
    private String safe(String s) { return s == null ? "" : s; }
}
