package com.autoparts.config;

import com.autoparts.model.*;
import com.autoparts.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class DataSeeder implements CommandLineRunner {

    @Autowired private ProductRepository productRepository;
    @Autowired private CategoryRepository categoryRepository;
    @Autowired private BrandRepository brandRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private VehicleRepository vehicleRepository;

    private final Map<String, String> catColor = new HashMap<>();

    @Override
    public void run(String... args) {
        if (productRepository.count() > 0) return;

        seedUsers();
        Map<String, Brand> brands = seedBrands();
        Map<String, Category> cats = seedCategories();
        seedGenericProducts(brands, cats);
        seedVehiclesAndParts(brands, cats);
        seedMotorcycles(brands, cats);
    }

    private void seedUsers() {
        User admin = new User();
        admin.setName("Admin");
        admin.setEmail("admin@autoparts.com");
        admin.setPassword("admin123");
        admin.setRole("ADMIN");
        userRepository.save(admin);

        User demo = new User();
        demo.setName("Demo Customer");
        demo.setEmail("demo@autoparts.com");
        demo.setPassword("demo123");
        demo.setRole("CUSTOMER");
        userRepository.save(demo);
    }

    private Map<String, Brand> seedBrands() {
        String[][] data = {
            {"Exide", "https://www.exideindustries.com", "Batteries & Power"},
            {"Amaron", "https://www.amaron.in", "Long-life Batteries"},
            {"MRF", "https://www.mrftyres.com", "Tyres"},
            {"Apollo", "https://www.apollotyres.com", "Tyres"},
            {"CEAT", "https://www.ceat.com", "Tyres"},
            {"JK Tyre", "https://www.jktyre.com", "Tyres"},
            {"Uno Minda", "https://www.unominda.com", "Switches, Lamps & Filters"},
            {"Lucas-TVS", "https://www.lucastvs.com", "Electricals"},
            {"Rane", "https://www.rane.co.in", "Brakes & Steering"},
            {"Gabriel", "https://www.gabriel.co.in", "Shock Absorbers"},
            {"Varroc", "https://www.varroc.com", "Lighting"},
            {"Lumax", "https://www.lumaxworld.in", "Lighting & Accessories"},
            {"Endurance", "https://www.endurancegroup.com", "Suspension & Braking"},
            {"Castrol India", "https://www.castrol.com/en_in/india/home.html", "Engine Oils"},
            {"Hero MotoCorp", "https://www.heromotocorp.com/", "Motorcycles & Genuine Parts"},
            {"Honda", "https://www.honda2wheelersindia.com/", "Motorcycles & Scooters"},
            {"Royal Enfield", "https://www.royalenfield.com/in/en/home/", "Motorcycles & Genuine Parts"},
            {"TVS", "https://www.tvsmotor.com/", "Motorcycles & Scooters"}
        };
        Map<String, Brand> map = new HashMap<>();
        for (String[] r : data) {
            Brand b = new Brand();
            b.setName(r[0]);
            b.setWebsiteUrl(r[1]);
            b.setTagline(r[2]);
            map.put(r[0], brandRepository.save(b));
        }
        return map;
    }

    private Map<String, Category> seedCategories() {
        String[][] data = {
            {"Engine Parts", "🔧", "1e3a8a"},
            {"Brakes", "🛑", "991b1b"},
            {"Suspension", "🔩", "7c2d12"},
            {"Electrical", "⚡", "a16207"},
            {"Batteries", "🔋", "166534"},
            {"Tyres", "🛞", "1f2937"},
            {"Lighting", "💡", "0e7490"},
            {"Lubricants", "🛢️", "b45309"},
            {"Filters", "🌀", "4338ca"},
            {"Accessories", "🎛️", "be185d"},
            {"Drivetrain", "⚙️", "334155"}
        };
        Map<String, Category> map = new HashMap<>();
        for (String[] r : data) {
            Category c = new Category();
            c.setName(r[0]);
            c.setIcon(r[1]);
            c.setImageUrl(photoFor(r[0]));
            catColor.put(r[0], r[2]);
            map.put(r[0], categoryRepository.save(c));
        }
        return map;
    }

    private void seedGenericProducts(Map<String, Brand> brands, Map<String, Category> cats) {
        String[][] rows = {
            {"Exide Mileage ML65 Car Battery 65Ah", "Batteries", "Exide", "6499", "Maintenance-free 65Ah battery with long service life, ideal for hatchbacks and sedans."},
            {"Exide Xplore 9Ah Bike Battery", "Batteries", "Exide", "1449", "Spill-proof sealed battery built for reliable starts in commuter and sports bikes."},
            {"Amaron Pro 55Ah Car Battery", "Batteries", "Amaron", "5799", "Calcium alloy technology with high cranking power and zero top-up maintenance."},
            {"Amaron Hi-Life Pro 35Ah Battery", "Batteries", "Amaron", "3999", "Dependable power for compact cars with a long warranty and quick recharge."},
            {"MRF ZVTV 185/65 R15 Tubeless Tyre", "Tyres", "MRF", "4850", "Quiet, durable all-round tyre designed for Indian highways and city roads."},
            {"MRF Revz-C 100/90-17 Bike Tyre", "Tyres", "MRF", "2299", "Sticky compound with superb cornering grip for performance motorcycles."},
            {"Apollo Amazer 4G Life 165/80 R14", "Tyres", "Apollo", "3999", "Long-life tyre with excellent mileage and strong wet-road grip."},
            {"Apollo Alnac 4G 205/55 R16", "Tyres", "Apollo", "6150", "Premium touring tyre with low rolling resistance and stable handling."},
            {"CEAT SecuraDrive 185/65 R15", "Tyres", "CEAT", "4250", "Safety-focused tyre with short braking distances on wet surfaces."},
            {"CEAT Zoom Plus 90/90-17 Bike Tyre", "Tyres", "CEAT", "1899", "Tough, long-lasting rear tyre for daily commuter bikes."},
            {"JK Tyre UX Royale 195/65 R15", "Tyres", "JK Tyre", "4650", "Comfort-oriented tyre with a refined ride and low noise."},
            {"JK Tyre Elanzo Touring 175/65 R14", "Tyres", "JK Tyre", "3790", "Balanced touring tyre for small cars with strong tread life."},
            {"Rane Front Brake Lining Set", "Brakes", "Rane", "1250", "Low-noise friction material delivering consistent, fade-free braking."},
            {"Uno Minda Ventilated Brake Disc Rotor", "Brakes", "Uno Minda", "2150", "Precision-machined ventilated rotor for cooler, stronger stopping."},
            {"Endurance Front Disc Brake Caliper", "Brakes", "Endurance", "3850", "Forged caliper with smooth piston action and long service life."},
            {"Rane Brake Shoe Set Rear Drum", "Brakes", "Rane", "980", "Durable rear brake shoes engineered for Indian driving conditions."},
            {"Gabriel Gas Shock Absorber Front", "Suspension", "Gabriel", "2899", "Gas-charged damper that keeps the ride smooth over rough roads."},
            {"Gabriel Ultra Rear Shock Absorber", "Suspension", "Gabriel", "2450", "Heavy-duty rear shock for better stability with luggage and passengers."},
            {"Rane Steering Tie Rod End", "Suspension", "Rane", "780", "Precise steering response with a hardened, long-lasting joint."},
            {"Endurance Front Fork Assembly Bike", "Suspension", "Endurance", "5400", "Telescopic fork assembly for responsive handling and comfort."},
            {"Lucas-TVS Alternator 12V 90A", "Electrical", "Lucas-TVS", "7800", "High-output alternator for dependable charging in all conditions."},
            {"Lucas-TVS Starter Motor 12V", "Electrical", "Lucas-TVS", "6200", "Powerful starter motor with quick, reliable engine cranking."},
            {"Uno Minda Twin Tone Horn Set", "Electrical", "Uno Minda", "899", "Loud, crisp twin-tone horn pair with easy plug-and-play wiring."},
            {"Lucas-TVS Ignition Coil", "Electrical", "Lucas-TVS", "1450", "Stable spark energy for smooth idling and strong acceleration."},
            {"Rane Engine Valve Set", "Engine Parts", "Rane", "3200", "Heat-resistant intake and exhaust valves for long engine life."},
            {"Uno Minda Spark Plug Set of 4", "Engine Parts", "Uno Minda", "799", "Iridium-tipped plugs for efficient combustion and better mileage."},
            {"Rane Timing Chain Tensioner", "Engine Parts", "Rane", "1850", "Keeps the timing chain tight for quiet, accurate valve timing."},
            {"Lumax Cygnus LED Headlight Bulb H4", "Lighting", "Lumax", "1599", "Bright white LED bulb with a sharp beam cut-off and low power draw."},
            {"Varroc LED Tail Lamp Assembly", "Lighting", "Varroc", "3499", "Modern LED tail lamp with crisp brake and indicator signature."},
            {"Uno Minda Fog Lamp Kit", "Lighting", "Uno Minda", "2299", "Wide-spread fog lamps that improve visibility in rain and mist."},
            {"Lumax LED Indicator Set Bike", "Lighting", "Lumax", "599", "Compact amber LED indicators that give your bike a sharper look."},
            {"Varroc Projector Headlamp Unit", "Lighting", "Varroc", "5200", "Projector headlamp with a focused beam for confident night driving."},
            {"Castrol MAGNATEC 5W-30 3.5L", "Lubricants", "Castrol India", "2799", "Synthetic-blend oil that protects the engine right from cold start."},
            {"Castrol GTX 20W-40 3.5L", "Lubricants", "Castrol India", "1899", "Trusted mineral engine oil for everyday cars and older engines."},
            {"Castrol ACTIV 4T 10W-30 1L Bike", "Lubricants", "Castrol India", "449", "Engine oil for 4-stroke bikes with smooth clutch and gear shifts."},
            {"Castrol Brake Fluid DOT 4 500ml", "Lubricants", "Castrol India", "399", "High boiling point brake fluid for dependable braking performance."},
            {"Uno Minda Air Filter Element", "Filters", "Uno Minda", "549", "High-capacity air filter trapping dust to protect your engine."},
            {"Lucas-TVS Oil Filter Spin-On", "Filters", "Lucas-TVS", "299", "Efficient oil filter that keeps lubricant clean between changes."},
            {"Uno Minda Cabin AC Filter", "Filters", "Uno Minda", "449", "Keeps dust and pollen out of your cabin for fresher air."},
            {"Uno Minda 12V Tyre Inflator", "Accessories", "Uno Minda", "1899", "Portable 12V air compressor with digital pressure display."},
            {"Lumax Leather Gear Shift Knob", "Accessories", "Lumax", "699", "Premium-feel leather knob with a comfortable, sporty grip."},
            {"Varroc Side Rear View Mirror Pair", "Accessories", "Varroc", "1299", "Wide-angle side mirrors with anti-glare coating."}
        };
        for (String[] r : rows) {
            saveProduct(r[0], r[4], Double.parseDouble(r[3]), cats.get(r[1]), brands.get(r[2]), null, "Universal");
        }
    }

    private void seedVehiclesAndParts(Map<String, Brand> brands, Map<String, Category> cats) {
        String[][] vehicles = {
            {"Maruti Suzuki", "Swift", "2005 - Present", "India's favourite sporty hatchback, loved for its zippy engine, sharp handling and low running costs.", "1.0", "b91c1c"},
            {"Hyundai", "Creta", "2015 - Present", "A feature-packed compact SUV with a premium cabin, strong road presence and flexible engine choices.", "1.35", "1d4ed8"},
            {"Tata", "Nexon", "2017 - Present", "India's safety-first compact SUV with a 5-star crash rating and bold, modern styling.", "1.25", "0f766e"},
            {"Honda", "City", "1998 - Present", "The benchmark premium sedan, known for refinement, reliability and a spacious, comfortable cabin.", "1.3", "475569"},
            {"Mahindra", "Scorpio-N", "2022 - Present", "A rugged, commanding full-size SUV built for highways, hills and everything in between.", "1.6", "111827"}
        };
        String[][] parts = {
            {"Front Brake Pad Set", "Brakes", "Rane", "1450", "Low-dust, low-noise friction material for consistent stopping."},
            {"Air Filter", "Filters", "Uno Minda", "520", "High-flow filter that protects the engine and helps fuel economy."},
            {"Oil Filter", "Filters", "Lucas-TVS", "320", "Keeps engine oil clean for longer engine life."},
            {"Front Shock Absorber", "Suspension", "Gabriel", "3200", "Gas-charged shock for a stable, comfortable ride."},
            {"LED Headlight Bulb", "Lighting", "Lumax", "1800", "Bright LED bulb for better visibility on dark roads."},
            {"Engine Oil 5W-30 3.5L", "Lubricants", "Castrol India", "2700", "Synthetic-blend oil for smooth, protected performance."},
            {"Car Battery", "Batteries", "Exide", "6200", "Maintenance-free battery with strong cranking power."},
            {"Tubeless Tyre", "Tyres", "MRF", "4800", "Durable tyre with confident grip in dry and wet conditions."}
        };
        for (String[] v : vehicles) {
            Vehicle ve = new Vehicle();
            ve.setMake(v[0]);
            ve.setModel(v[1]);
            ve.setYearRange(v[2]);
            ve.setDescription(v[3]);
            ve.setImageUrl(vehiclePhoto(v[0], v[1]));
            ve = vehicleRepository.save(ve);

            double factor = Double.parseDouble(v[4]);
            for (String[] t : parts) {
                double price = Math.round(Double.parseDouble(t[3]) * factor / 10.0) * 10.0;
                String name = t[2] + " " + t[0] + " for " + v[1];
                String desc = t[4] + " Application shown for research only. Confirm exact generation, variant, engine and manufacturer part number before purchase.";
                saveProduct(name, desc, price, cats.get(t[1]), brands.get(t[2]), ve, v[0] + " " + v[1]);
            }
        }
    }

    private void saveProduct(String name, String desc, double price, Category c, Brand b, Vehicle v, String compat) {
        Product p = new Product();
        p.setName(name);
        p.setDescription(desc);
        p.setPrice(null); // No fabricated or stale retail pricing in a referral catalogue.
        p.setMrp(null);
        p.setStock(0); // discovery-only catalogue: inventory is not sold or represented as live
        p.setRating(null);
        p.setRatingCount(0);
        p.setPartNumber("Check manufacturer catalogue");
        p.setListingType("BRAND-CATALOGUE");
        p.setFitmentNote("Compatibility is indicative only. Confirm the exact part number, variant, year and engine with the manufacturer or authorised seller before purchase.");
        p.setImageUrl(photoFor(c.getName()));
        // Only show the category reference image until an exact SKU image is supplied.
        // Do not fabricate a multi-angle gallery from unrelated category photographs.
        p.setGalleryImages("");
        p.setOfficialLink(b.getWebsiteUrl());
        p.setCompatibleModels(compat);
        p.setCategory(c);
        p.setBrand(b);
        p.setVehicle(v);
        productRepository.save(p);
    }

    private void seedMotorcycles(Map<String, Brand> brands, Map<String, Category> cats) {
        String[][] bikes = {
            {"Hero MotoCorp", "Splendor Plus", "2005 - Present", "Everyday commuter motorcycle platform. Confirm exact generation, variant and engine before selecting parts."},
            {"Honda", "Activa 6G", "2020 - Present", "Popular automatic scooter platform. Confirm model year and trim for service components."},
            {"Royal Enfield", "Classic 350", "2021 - Present", "Modern J-series retro roadster platform. Confirm model generation and ABS variant."},
            {"TVS", "Apache RTR 160", "2007 - Present", "Sport commuter motorcycle family. Confirm exact displacement, generation and variant."}
        };
        String[][] parts = {
            {"Engine Oil 4T", "Lubricants", "Castrol India", "Motorcycle-specific lubricant; match viscosity and JASO/API specification to the owner's manual."},
            {"Front Brake Pad Set", "Brakes", "Endurance", "Brake friction component; confirm caliper type, year and exact part code."},
            {"Air Filter Element", "Filters", "Uno Minda", "Engine intake filter; confirm dimensions and exact vehicle variant."},
            {"Battery Assembly", "Batteries", "Exide", "Starting battery; verify voltage, capacity, polarity and case dimensions."},
            {"Chain & Sprocket Kit", "Drivetrain", "Endurance", "Final-drive wear kit; confirm tooth count, pitch and chain length."},
            {"Rear Shock Absorber", "Suspension", "Gabriel", "Suspension component; verify mounting points and vehicle-specific application."},
            {"LED Headlamp Assembly", "Lighting", "Lumax", "Lighting assembly; check connector, beam pattern and road-legal approval."}
        };
        for (String[] b : bikes) {
            Vehicle v = new Vehicle(); v.setMake(b[0]); v.setModel(b[1]); v.setYearRange(b[2]); v.setDescription(b[3]); v.setImageUrl(vehiclePhoto(b[0], b[1])); v = vehicleRepository.save(v);
            for (String[] item : parts) {
                saveProduct(b[0] + " " + b[1] + " — " + item[0], item[3], 0, cats.get(item[1]), brands.get(item[2]), v, b[0] + " " + b[1]);
            }
        }
    }

    private String vehiclePhoto(String make, String model) {
        String key = (make + " " + model).toLowerCase();
        // Editorial vehicle imagery is intentionally labelled as non-exact-trim photography in the UI.
        if (key.contains("splendor")) return "https://www.heromotocorp.com/en-in/motorcycles/practical/media_1351a67f39f393e27e5d372ebed3ad5b147eb3cf3.avif?width=2000&format=webply&optimize=medium";
        if (key.contains("activa")) return "https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=1400&q=88";
        if (key.contains("classic 350")) return "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=1400&q=88";
        if (key.contains("apache")) return "https://placehold.co/1400x900/e7e8e5/24313a?text=TVS+APACHE+RTR+160+IMAGE";
        return switch (make.toLowerCase()) {
            case "maruti suzuki" -> "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1400&q=88";
            case "hyundai" -> "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=1400&q=88";
            case "tata" -> "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1400&q=88";
            case "honda" -> "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1400&q=88";
            case "mahindra" -> "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=1400&q=88";
            default -> "https://placehold.co/1400x900/e7e8e5/24313a?text=VEHICLE+IMAGE+PENDING";
        };
    }

    // Category-level images are deliberately not presented as exact SKU photographs.
    private String photoFor(String category) {
        return switch (category) {
            case "Batteries" -> "https://images.unsplash.com/photo-1606577924006-27d39b132ae2?auto=format&fit=crop&w=1000&q=85";
            case "Tyres" -> "https://shop.shibatire.com/cdn/shop/files/R02_7abf88f7-0a46-4e6b-ab71-90bb4f1df5de.jpg?v=1724234373&width=1946";
            case "Brakes" -> "https://www.kingpartswarehouse.com.au/cdn/shop/collections/brake-pad-and-disc-rotor.png?v=1758623869&width=1500";
            case "Suspension" -> "https://static.winparts.net/drivetrain-suspension/shock-absorbers-coil-springs/shock-absorbers/c10/shock-absorber-monroe-original-gas-technology-g7306/p4355298_900_900.jpg";
            case "Lubricants" -> "https://cdn.salla.sa/GYRwqj/6ca2a13a-1f88-4663-8720-8c455ecd1a05-500x500-NUYZ9KwgOsqgI26TD13Uc0ifbs4ZlTKhHRER3eAK.png";
            case "Electrical" -> "https://www.magnetimarelli-parts-and-services.pt/news/2018/news/catalogo-alternadores-e-motores-de-arranque/_jcr_content/root/enh_responsivegrid/mm_container/par_0/twovariantscolumn/par_0/image.coreimg.jpeg/1714663683362/alternatori-e-motori-avviamento.jpeg";
            case "Filters" -> "https://res.cloudinary.com/knfilters-com/image/upload/c_lpad,dpr_2.0,f_auto,q_auto/v1/media/wysiwyg/p/a/panel-and-round-filter.jpg";
            case "Lighting" -> "https://placehold.co/1000x700/e7e8e5/24313a?text=AUTOMOTIVE+LIGHTING";
            case "Engine Parts" -> "https://placehold.co/1000x700/e7e8e5/24313a?text=ENGINE+COMPONENTS";
            case "Drivetrain" -> "https://placehold.co/1000x700/e7e8e5/24313a?text=DRIVETRAIN+COMPONENTS";
            default -> "https://placehold.co/1000x700/e7e8e5/24313a?text=AUTOMOTIVE+PARTS";
        };
    }

    private String img(int w, int h, String hex, String text) {
        String t = text.replaceAll("[^A-Za-z0-9 ]", " ").trim().replaceAll("\\s+", "+");
        return "https://placehold.co/" + w + "x" + h + "/" + hex + "/ffffff?text=" + t;
    }
}
