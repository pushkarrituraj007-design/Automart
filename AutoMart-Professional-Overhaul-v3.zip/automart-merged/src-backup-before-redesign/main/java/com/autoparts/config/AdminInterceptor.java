package com.autoparts.config;

import com.autoparts.model.User;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.servlet.HandlerInterceptor;

public class AdminInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession(false);
        Object u = (session == null) ? null : session.getAttribute("loggedInUser");
        if (u instanceof User && "ADMIN".equals(((User) u).getRole())) {
            return true;
        }
        response.sendRedirect(request.getContextPath() + "/login?denied=true");
        return false;
    }
}
