package com.autoparts.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.HandlerInterceptor;

public class AuthenticationInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (request.getSession(false) != null && request.getSession(false).getAttribute("loggedInUser") != null) return true;
        response.sendRedirect(request.getContextPath() + "/login?required=true");
        return false;
    }
}
