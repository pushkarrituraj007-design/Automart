package com.autoparts.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new AuthenticationInterceptor())
                .addPathPatterns("/**")
                .excludePathPatterns("/", "/login", "/register", "/logout", "/error", "/css/**", "/js/**", "/images/**", "/webjars/**", "/favicon.ico");
        registry.addInterceptor(new AdminInterceptor()).addPathPatterns("/admin/**");
    }
}
