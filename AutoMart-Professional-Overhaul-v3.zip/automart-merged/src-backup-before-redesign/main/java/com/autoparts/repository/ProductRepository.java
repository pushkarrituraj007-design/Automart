package com.autoparts.repository;

import com.autoparts.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByCategoryId(Long categoryId);
    List<Product> findByBrandId(Long brandId);
    List<Product> findByVehicleId(Long vehicleId);
    List<Product> findByNameContainingIgnoreCase(String keyword);
}
