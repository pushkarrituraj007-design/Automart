package com.autoparts.controller;

import com.autoparts.model.Vehicle;
import com.autoparts.repository.ProductRepository;
import com.autoparts.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class VehicleController {

    @Autowired private VehicleRepository vehicleRepository;
    @Autowired private ProductRepository productRepository;

    @GetMapping("/vehicles")
    public String list(Model model) {
        model.addAttribute("vehicles", vehicleRepository.findAll());
        return "vehicles";
    }

    @GetMapping("/vehicles/{id}/tour")
    public String tour(@PathVariable Long id, Model model) {
        Vehicle vehicle = vehicleRepository.findById(id).orElseThrow();
        model.addAttribute("vehicle", vehicle);
        return "vehicle-tour";
    }

    @GetMapping("/vehicles/{id}")
    public String detail(@PathVariable Long id, Model model) {
        Vehicle vehicle = vehicleRepository.findById(id).orElseThrow();
        model.addAttribute("vehicle", vehicle);
        model.addAttribute("parts", productRepository.findByVehicleId(id));
        return "vehicle-detail";
    }
}
