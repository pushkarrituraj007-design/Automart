package com.autoparts.controller;

import com.autoparts.model.Cart;
import com.autoparts.model.CartItem;
import com.autoparts.model.Product;
import com.autoparts.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class CartController {

    @Autowired private ProductRepository productRepository;
    @Autowired private Cart cart;

    @GetMapping("/cart")
    public String viewCart(Model model) {
        model.addAttribute("cart", cart);
        return "cart";
    }

    @PostMapping("/cart/add/{id}")
    public String addToCart(@PathVariable Long id, @RequestParam(defaultValue = "1") int quantity) {
        Product p = productRepository.findById(id).orElseThrow();
        CartItem item = new CartItem(p.getId(), p.getName(), p.getPrice(), p.getImageUrl(), quantity);
        cart.addItem(item);
        return "redirect:/cart";
    }

    @PostMapping("/cart/remove/{id}")
    public String removeFromCart(@PathVariable Long id) {
        cart.removeItem(id);
        return "redirect:/cart";
    }

    @GetMapping("/checkout")
    public String checkout(Model model) {
        model.addAttribute("cart", cart);
        return "checkout";
    }

    @PostMapping("/checkout/confirm")
    public String confirmOrder() {
        cart.clear();
        return "redirect:/home?orderSuccess=true";
    }
}
