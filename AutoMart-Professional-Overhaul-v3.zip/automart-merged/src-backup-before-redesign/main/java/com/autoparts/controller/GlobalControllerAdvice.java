package com.autoparts.controller;

import com.autoparts.model.Cart;
import com.autoparts.model.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalControllerAdvice {

    @Autowired
    private Cart cart;

    @ModelAttribute("cartItemCount")
    public int cartItemCount() {
        return cart.getTotalItems();
    }

    @ModelAttribute("currentUser")
    public User currentUser(HttpSession session) {
        Object u = session.getAttribute("loggedInUser");
        return (u instanceof User) ? (User) u : null;
    }

    @ModelAttribute("isAdmin")
    public boolean isAdmin(HttpSession session) {
        Object u = session.getAttribute("loggedInUser");
        return (u instanceof User) && "ADMIN".equals(((User) u).getRole());
    }
}
