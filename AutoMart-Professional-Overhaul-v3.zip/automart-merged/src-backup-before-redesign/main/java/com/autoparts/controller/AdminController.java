package com.autoparts.controller;

import com.autoparts.model.Brand;
import com.autoparts.model.Category;
import com.autoparts.model.Product;
import com.autoparts.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired private ProductRepository productRepository;
    @Autowired private CategoryRepository categoryRepository;
    @Autowired private BrandRepository brandRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private VehicleRepository vehicleRepository;

    @GetMapping({"", "/", "/dashboard"})
    public String dashboard(Model model) {
        List<Product> all = productRepository.findAll();
        model.addAttribute("totalProducts", all.size());
        model.addAttribute("totalCategories", categoryRepository.count());
        model.addAttribute("totalBrands", brandRepository.count());
        model.addAttribute("totalUsers", userRepository.count());
        model.addAttribute("totalVehicles", vehicleRepository.count());
        return "admin/dashboard";
    }

    @GetMapping("/products")
    public String products(Model model) {
        model.addAttribute("products", productRepository.findAll());
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("brands", brandRepository.findAll());
        return "admin/products";
    }

    @PostMapping("/products/add")
    public String add(@RequestParam String name,
                      @RequestParam(required = false) String description,
                      @RequestParam(required = false) Double price,
                      @RequestParam(required = false) Integer stock,
                      @RequestParam(required = false) String compatibleModels,
                      @RequestParam(required = false) String imageUrl,
                      @RequestParam Long categoryId,
                      @RequestParam Long brandId) {
        Category category = categoryRepository.findById(categoryId).orElseThrow();
        Brand brand = brandRepository.findById(brandId).orElseThrow();
        String image = (imageUrl == null || imageUrl.isBlank())
                ? "https://placehold.co/600x450/334155/ffffff?text=New+Part" : imageUrl.trim();

        Product p = new Product();
        p.setName(name);
        p.setDescription(description);
        p.setPrice(null);
        p.setMrp(null);
        p.setStock(0);
        p.setImageUrl(image);
        p.setGalleryImages(image);
        p.setOfficialLink(brand.getWebsiteUrl());
        p.setCompatibleModels(compatibleModels == null || compatibleModels.isBlank() ? "Not specified" : compatibleModels.trim());
        p.setRating(null);
        p.setRatingCount(0);
        p.setListingType("BRAND-CATALOGUE");
        p.setPartNumber("Check manufacturer catalogue");
        p.setFitmentNote("Confirm exact compatibility with the manufacturer or authorised seller.");
        p.setCategory(category);
        p.setBrand(brand);
        productRepository.save(p);
        return "redirect:/admin/products?added=true";
    }

    @PostMapping("/products/delete/{id}")
    public String delete(@PathVariable Long id) {
        productRepository.deleteById(id);
        return "redirect:/admin/products?deleted=true";
    }
}
