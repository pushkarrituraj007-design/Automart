package com.autoparts.controller;

import com.autoparts.model.User;
import com.autoparts.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/register")
    public String registerForm(Model model) { model.addAttribute("user", new User()); return "register"; }

    @PostMapping("/register")
    public String register(@ModelAttribute User user, Model model) {
        if (user.getName() == null || user.getName().isBlank() || user.getEmail() == null || user.getPassword() == null || user.getPassword().length() < 8) {
            model.addAttribute("error", "Enter your name, a valid email and a password of at least 8 characters.");
            return "register";
        }
        user.setEmail(user.getEmail().trim().toLowerCase());
        if (userRepository.findByEmail(user.getEmail()) != null) { model.addAttribute("error", "This email is already registered."); return "register"; }
        user.setId(null); user.setRole("CUSTOMER"); user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
        return "redirect:/login?registered=true";
    }

    @GetMapping("/login")
    public String loginForm() { return "login"; }

    @PostMapping("/login")
    public String login(@RequestParam String email, @RequestParam String password, HttpSession session, Model model) {
        User user = userRepository.findByEmail(email.trim().toLowerCase());
        boolean valid = false;
        if (user != null && user.getPassword() != null) {
            String stored = user.getPassword();
            valid = stored.startsWith("$2a$") || stored.startsWith("$2b$") || stored.startsWith("$2y$")
                    ? passwordEncoder.matches(password, stored) : stored.equals(password);
            if (valid && !(stored.startsWith("$2a$") || stored.startsWith("$2b$") || stored.startsWith("$2y$"))) {
                user.setPassword(passwordEncoder.encode(password)); userRepository.save(user);
            }
        }
        if (valid) {
            session.setAttribute("loggedInUser", user);
            return "ADMIN".equals(user.getRole()) ? "redirect:/admin/dashboard" : "redirect:/home";
        }
        model.addAttribute("error", "Email or password is incorrect.");
        return "login";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) { session.invalidate(); return "redirect:/login?loggedOut=true"; }
}
