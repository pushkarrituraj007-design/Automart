package com.autoparts.controller;

import com.autoparts.model.Product;
import com.autoparts.repository.ProductRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.*;

@Controller
public class ShortlistController {
    private final ProductRepository products;
    public ShortlistController(ProductRepository products) { this.products = products; }

    @GetMapping("/shortlist")
    public String shortlist() { return "shortlist"; }

    @GetMapping("/shortlist/items")
    @org.springframework.web.bind.annotation.ResponseBody
    public List<Map<String,Object>> items(@RequestParam(required=false) String ids) {
        if (ids == null || ids.isBlank()) return List.of();
        List<Map<String,Object>> result = new ArrayList<>();
        for (String raw : ids.split(",")) {
            try {
                Product p = products.findById(Long.parseLong(raw)).orElse(null);
                if (p == null) continue;
                Map<String,Object> row = new LinkedHashMap<>();
                row.put("id", p.getId()); row.put("name", p.getName()); row.put("description", p.getDescription());
                row.put("imageUrl", p.getImageUrl()); row.put("partNumber", p.getPartNumber());
                row.put("brand", p.getBrand() == null ? "Manufacturer not listed" : p.getBrand().getName());
                row.put("category", p.getCategory() == null ? "Unclassified" : p.getCategory().getName());
                result.add(row);
            } catch (NumberFormatException ignored) { }
        }
        return result;
    }
}
