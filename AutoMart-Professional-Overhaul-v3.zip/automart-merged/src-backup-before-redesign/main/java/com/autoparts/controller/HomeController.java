package com.autoparts.controller;

import com.autoparts.model.Product;
import com.autoparts.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Controller
public class HomeController {

    @Autowired private ProductRepository productRepository;
    @Autowired private CategoryRepository categoryRepository;
    @Autowired private BrandRepository brandRepository;
    @Autowired private VehicleRepository vehicleRepository;

    @GetMapping("/")
    public String landing() {
        return "redirect:/login";
    }

    @GetMapping("/home")
    public String home(Model model) {
        List<Product> featured = productRepository.findAll().stream()
                .filter(p -> p.getVehicle() == null)
                .sorted(Comparator.comparing(
        Product::getRating,
        Comparator.nullsLast(Comparator.reverseOrder())
))
                .limit(10)
                .collect(Collectors.toList());
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("brands", brandRepository.findAll().stream().limit(12).collect(Collectors.toList()));
        model.addAttribute("featuredProducts", featured);
        model.addAttribute("vehicles", vehicleRepository.findAll());
        model.addAttribute("productCount", productRepository.count());
        model.addAttribute("brandCount", brandRepository.count());
        model.addAttribute("vehicleCount", vehicleRepository.count());
        model.addAttribute("categoryCount", categoryRepository.count());
        return "home";
    }

    @GetMapping("/categories")
    public String categories(Model model) {
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("counts", countBy(p -> p.getCategory() == null ? null : p.getCategory().getId()));
        return "categories";
    }

    @GetMapping("/brands")
    public String brands(Model model) {
        model.addAttribute("brands", brandRepository.findAll());
        model.addAttribute("counts", countBy(p -> p.getBrand() == null ? null : p.getBrand().getId()));
        return "brands";
    }

    @GetMapping("/about")
    public String about() {
        return "about";
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact";
    }

    @PostMapping("/contact")
    public String contactSubmit(Model model) {
        model.addAttribute("sent", true);
        return "contact";
    }

    private Map<Long, Long> countBy(Function<Product, Long> keyFn) {
        Map<Long, Long> map = new HashMap<>();
        for (Product p : productRepository.findAll()) {
            Long key = keyFn.apply(p);
            if (key != null) map.merge(key, 1L, Long::sum);
        }
        return map;
    }
}
