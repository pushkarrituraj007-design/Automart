package com.autoparts.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Product {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @Column(length = 1000)
    private String description;
    private Double price;
    private Double mrp;
    private Integer stock;
    @Column(length = 2048)
    private String imageUrl;
    @Column(length = 2048)
    private String officialLink;
    private String compatibleModels;
    private String partNumber;
    private String listingType = "AFTERMARKET";
    private String fitmentNote;
    private Double rating;
    private Integer ratingCount;
    @Column(length = 2000)
    private String galleryImages;

    @ManyToOne
    private Category category;
    @ManyToOne
    private Brand brand;
    @ManyToOne
    private Vehicle vehicle;

    public Product() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }
    public Double getMrp() { return mrp; }
    public void setMrp(Double mrp) { this.mrp = mrp; }
    public Integer getStock() { return stock; }
    public void setStock(Integer stock) { this.stock = stock; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public String getOfficialLink() { return officialLink; }
    public void setOfficialLink(String officialLink) { this.officialLink = officialLink; }
    public String getPartNumber() { return partNumber; }
    public void setPartNumber(String partNumber) { this.partNumber = partNumber; }
    public String getListingType() { return listingType; }
    public void setListingType(String listingType) { this.listingType = listingType; }
    public String getFitmentNote() { return fitmentNote; }
    public void setFitmentNote(String fitmentNote) { this.fitmentNote = fitmentNote; }
    public String getCompatibleModels() { return compatibleModels; }
    public void setCompatibleModels(String compatibleModels) { this.compatibleModels = compatibleModels; }
    public Double getRating() { return rating; }
    public void setRating(Double rating) { this.rating = rating; }
    public Integer getRatingCount() { return ratingCount; }
    public void setRatingCount(Integer ratingCount) { this.ratingCount = ratingCount; }
    public String getGalleryImages() { return galleryImages; }
    public void setGalleryImages(String galleryImages) { this.galleryImages = galleryImages; }
    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
    public Brand getBrand() { return brand; }
    public void setBrand(Brand brand) { this.brand = brand; }
    public Vehicle getVehicle() { return vehicle; }
    public void setVehicle(Vehicle vehicle) { this.vehicle = vehicle; }

    public int getDiscountPercent() {
        if (mrp == null || price == null || mrp <= price || mrp == 0) return 0;
        return (int) Math.round((mrp - price) * 100.0 / mrp);
    }

    public List<String> getGalleryList() {
        List<String> list = new ArrayList<>();
        if (galleryImages != null && !galleryImages.isBlank()) {
            for (String s : galleryImages.split(",")) {
                if (!s.isBlank()) list.add(s.trim());
            }
        }
        return list;
    }
}
