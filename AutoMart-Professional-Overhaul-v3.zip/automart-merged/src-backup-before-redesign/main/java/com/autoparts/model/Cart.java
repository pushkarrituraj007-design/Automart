package com.autoparts.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class Cart {
    private Map<Long, CartItem> items = new LinkedHashMap<>();

    public Map<Long, CartItem> getItems() { return items; }
    public void setItems(Map<Long, CartItem> items) { this.items = items; }

    public void addItem(CartItem item) {
        if (items.containsKey(item.getProductId())) {
            CartItem existing = items.get(item.getProductId());
            existing.setQuantity(existing.getQuantity() + item.getQuantity());
        } else {
            items.put(item.getProductId(), item);
        }
    }

    public void removeItem(Long productId) {
        items.remove(productId);
    }

    public double getTotal() {
        double total = 0;
        for (CartItem item : items.values()) {
            total += item.getSubtotal();
        }
        return total;
    }

    public int getTotalItems() {
        int count = 0;
        for (CartItem item : items.values()) {
            count += item.getQuantity();
        }
        return count;
    }

    public void clear() {
        items.clear();
    }
}