package com.autoparts.service;

import com.autoparts.model.Product;
import com.autoparts.model.Vehicle;
import org.springframework.stereotype.Service;

/**
 * Conservative fitment evaluation. A catalogue association is not treated as
 * verified vehicle/variant compatibility. Exact fitment requires a verified
 * application record, which this MVP schema does not yet store.
 */
@Service
public class FitmentService {
    public FitmentResult evaluate(Product product, Vehicle vehicle) {
        if (product == null || vehicle == null)
            return new FitmentResult(Status.INSUFFICIENT_DATA, "Choose a vehicle and a part to evaluate fitment.");

        boolean linked = product.getVehicle() != null
                && product.getVehicle().getId().equals(vehicle.getId());
        boolean textMatch = product.getCompatibleModels() != null
                && product.getCompatibleModels().toLowerCase()
                    .contains((vehicle.getMake() + " " + vehicle.getModel()).toLowerCase());

        if (linked || textMatch)
            return new FitmentResult(Status.INDICATIVE,
                    "This listing is associated with the selected model only. Confirm year, generation, variant, engine and OEM part number with the manufacturer or supplier.");

        return new FitmentResult(Status.NOT_MATCHED,
                "No catalogue association found for this vehicle. This does not prove the part is incompatible.");
    }

    public enum Status { INDICATIVE, NOT_MATCHED, INSUFFICIENT_DATA }
    public record FitmentResult(Status status, String explanation) {}
}
