package com.autoparts.service;

import com.autoparts.model.Product;
import com.autoparts.repository.ProductRepository;
import org.springframework.stereotype.Service;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Application-layer catalogue rules. Controllers remain thin; all matching
 * and ordering is performed in Java and can later be backed by indexed queries.
 */
@Service
public class CatalogueService {
    private final ProductRepository products;
    public CatalogueService(ProductRepository products) { this.products = products; }

    public List<Product> all() {
        return products.findAll().stream()
                .sorted(Comparator.comparing(p -> safe(p.getName())))
                .toList();
    }

    public List<Product> search(String query) {
        if (query == null || query.isBlank()) return all();
        String term = query.strip().toLowerCase(Locale.ROOT);
        return products.findAll().stream()
                .filter(p -> contains(p.getName(), term)
                        || contains(p.getDescription(), term)
                        || contains(p.getPartNumber(), term)
                        || contains(p.getCompatibleModels(), term)
                        || (p.getBrand() != null && contains(p.getBrand().getName(), term))
                        || (p.getCategory() != null && contains(p.getCategory().getName(), term)))
                .sorted(Comparator.comparing(p -> safe(p.getName())))
                .toList();
    }

    private boolean contains(String value, String term) {
        return value != null && value.toLowerCase(Locale.ROOT).contains(term);
    }
    private String safe(String value) { return value == null ? "" : value; }
}
