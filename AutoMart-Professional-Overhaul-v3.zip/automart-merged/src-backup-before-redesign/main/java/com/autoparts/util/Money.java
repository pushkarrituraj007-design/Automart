package com.autoparts.util;

import org.springframework.stereotype.Component;
import java.text.NumberFormat;
import java.util.Locale;

@Component("money")
public class Money {
    public String inr(Number value) {
        if (value == null) return "";
        NumberFormat fmt = NumberFormat.getNumberInstance(Locale.forLanguageTag("en-IN"));
        fmt.setMaximumFractionDigits(0);
        return "₹" + fmt.format(value.doubleValue());
    }
}
