(() => {
  const key = 'automart.shortlist.v1';
  const host = document.getElementById('shortlist-products');
  const count = document.getElementById('shortlist-count');
  const read = () => { try { return JSON.parse(localStorage.getItem(key) || '[]').map(String); } catch { return []; } };
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function render() {
    const ids = read(); count.textContent = `${ids.length} SAVED ${ids.length === 1 ? 'REFERENCE' : 'REFERENCES'}`;
    if (!ids.length) { host.innerHTML = '<div class="shortlist-empty-state"><span class="eyebrow">YOUR WORKSPACE IS CLEAR</span><h2>No saved parts yet.</h2><p>Save a part from any catalogue page and it will appear here for comparison.</p><a class="shortlist-cta" href="/products">Explore the catalogue →</a></div>'; return; }
    host.innerHTML = '<p class="shortlist-empty">Loading saved references…</p>';
    try {
      const response = await fetch(`/shortlist/items?ids=${encodeURIComponent(ids.join(','))}`);
      if (!response.ok) throw new Error('Could not load saved items');
      const rows = await response.json();
      host.innerHTML = rows.length ? rows.map(p => `<article class="shortlist-card"><a class="shortlist-card-image" href="/products/${p.id}"><img src="${escapeHtml(p.imageUrl || '')}" alt="${escapeHtml(p.category)} category reference" loading="lazy"><span>CATEGORY REFERENCE</span></a><div class="shortlist-card-copy"><small>${escapeHtml(p.brand)} / ${escapeHtml(p.category)}</small><h3><a href="/products/${p.id}">${escapeHtml(p.name)}</a></h3><p>${escapeHtml(p.description)}</p><div class="shortlist-card-actions"><a href="/products/${p.id}">Inspect reference ↗</a><button type="button" data-remove="${p.id}">Remove</button></div></div></article>`).join('') : '<div class="shortlist-empty-state"><h2>Saved references unavailable.</h2><p>Some saved items may have been removed from the catalogue.</p><a class="shortlist-cta" href="/products">Browse catalogue →</a></div>';
    } catch { host.innerHTML = '<p class="shortlist-empty">Could not load saved references. Refresh the page to try again.</p>'; }
  }
  host.addEventListener('click', event => { const button = event.target.closest('[data-remove]'); if (!button) return; localStorage.setItem(key, JSON.stringify(read().filter(id => id !== button.dataset.remove))); render(); });
  render();
})();
