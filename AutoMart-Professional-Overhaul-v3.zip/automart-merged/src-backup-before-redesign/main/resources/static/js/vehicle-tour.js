(() => {
  const views = {
    exterior: { label:'01 / EXTERIOR OVERVIEW', title:'Exterior overview', description:'Begin with visible body areas and move into the main exterior component groups.', caption:'Exterior overview', items:['Body panels','Lighting assemblies','Wheels and tyres','Glass and mirrors'] },
    interior: { label:'02 / INTERIOR EXPLORATION', title:'Interior exploration', description:'Explore the cabin as a set of distinct areas. Exact interior equipment varies by generation and trim.', caption:'Interior reference', items:['Dashboard and instruments','Steering and controls','Seats and restraints','Infotainment and console'] },
    mechanical: { label:'03 / MECHANICAL SYSTEMS', title:'Mechanical systems', description:'Inspect the major mechanical systems and follow their component relationships into the parts catalogue.', caption:'Mechanical systems', items:['Engine and powertrain','Transmission and drivetrain','Braking system','Suspension and steering','Cooling and exhaust'] },
    electrical: { label:'04 / ELECTRICAL SYSTEMS', title:'Electrical systems', description:'Explore electrical and lighting groups. Component layouts must be checked against the exact vehicle configuration.', caption:'Electrical systems', items:['Battery and charging','Starter and ignition','Sensors and control units','Exterior and interior lighting'] }
  };
  const $ = id => document.getElementById(id);
  const tabs = [...document.querySelectorAll('[data-tour]')];
  function select(name) { const view = views[name]; if (!view) return; tabs.forEach(tab => tab.classList.toggle('active', tab.dataset.tour === name)); $('tour-view-label').textContent = view.label; $('tour-title').textContent = view.title; $('tour-description').textContent = view.description; $('tour-caption').textContent = view.caption; $('tour-hotspots').innerHTML = view.items.map(item => `<button type="button" data-hotspot="${item}">${item}<span>↗</span></button>`).join(''); }
  tabs.forEach(tab => tab.addEventListener('click', () => select(tab.dataset.tour)));
  $('tour-hotspots').addEventListener('click', event => { const item = event.target.closest('[data-hotspot]'); if (!item) return; document.querySelectorAll('[data-hotspot]').forEach(button => button.classList.toggle('selected', button === item)); $('tour-caption').textContent = item.dataset.hotspot; });
})();
