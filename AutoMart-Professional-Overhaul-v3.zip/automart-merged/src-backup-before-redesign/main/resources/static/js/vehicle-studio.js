(() => {
  const canvas = document.getElementById('vehicle3d');
  const $ = (s, root=document) => root.querySelector(s), $$ = (s, root=document) => [...root.querySelectorAll(s)];
  if (!canvas || !window.THREE) return;
  const modelName = `${canvas.dataset.vehicleMake || ''} ${canvas.dataset.vehicleModel || ''}`.toLowerCase();
  const isMotorcycle = /splendor|activa|classic 350|apache|motorcycle|scooter|bike/.test(modelName);
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x111c22);
  const camera = new THREE.PerspectiveCamera(34, 1, .1, 100); camera.position.set(6, 4.1, 7.4);
  const renderer = new THREE.WebGLRenderer({canvas, antialias:true, alpha:false}); renderer.setPixelRatio(Math.min(devicePixelRatio,2)); renderer.shadowMap.enabled=true; renderer.outputEncoding=THREE.sRGBEncoding;
  scene.add(new THREE.HemisphereLight(0xe7eee9,0x26343a,2)); const key=new THREE.DirectionalLight(0xf3f0e8,2.2); key.position.set(4,8,5); key.castShadow=true; scene.add(key);
  const fill=new THREE.PointLight(0x91b3b2,1.5,20); fill.position.set(-5,3,-3); scene.add(fill);
  const vehicle=new THREE.Group(); scene.add(vehicle);
  const paint=new THREE.MeshStandardMaterial({color:0x788f8a,metalness:.58,roughness:.3});
  const glass=new THREE.MeshStandardMaterial({color:0x253c43,metalness:.35,roughness:.2});
  const rubber=new THREE.MeshStandardMaterial({color:0x101518,roughness:.9});
  const metal=new THREE.MeshStandardMaterial({color:0xb8c0bb,metalness:.8,roughness:.25});
  const dark=new THREE.MeshStandardMaterial({color:0x283137,metalness:.55,roughness:.5});
  const lamp=new THREE.MeshStandardMaterial({color:0xd8e6cf,emissive:0x728e6d,emissiveIntensity:.5});
  function mesh(geometry, material, x=0,y=0,z=0, group=vehicle){const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;group.add(m);return m;}
  function box(w,h,d,material,x,y,z,group=vehicle){return mesh(new THREE.BoxGeometry(w,h,d),material,x,y,z,group);}
  function cylinder(radiusTop,radiusBottom,height,material,x,y,z,rotationX=0,rotationZ=0,group=vehicle){const m=mesh(new THREE.CylinderGeometry(radiusTop,radiusBottom,height,32),material,x,y,z,group);m.rotation.x=rotationX;m.rotation.z=rotationZ;return m;}
  function wheel(x,z,r=.48){const g=new THREE.Group();g.position.set(x,r,z);vehicle.add(g);const tyre=cylinder(r,r,.25,rubber,0,0,0,0,Math.PI/2,g);const rim=cylinder(r*.53,r*.53,.27,metal,0,0,0,0,Math.PI/2,g);for(let i=0;i<8;i++){const spoke=box(.025,r*.78,.025,dark,0,0,0,g);spoke.rotation.x=i*Math.PI/4;}return g;}
  let wheels=[];
  if(isMotorcycle){
    // Distinct motorcycle silhouette: two wheels, narrow frame, tank, saddle, fork and exhaust.
    wheels=[wheel(0,1.48,.43),wheel(0,-1.42,.43)];
    box(.12,.16,2.1,dark,0,.92,0); // frame spine
    mesh(new THREE.SphereGeometry(.43,28,20),paint,0,1.25,.18).scale.set(.58,.62,.82); // fuel tank
    box(.48,.18,.92,dark,0,1.17,-.67); // engine casing
    box(.48,.13,.76,paint,0,1.48,-.98); // seat
    const frontFork1=cylinder(.045,.045,1.22,metal,-.13,1.12,1.12,.14,0);const frontFork2=cylinder(.045,.045,1.22,metal,.13,1.12,1.12,.14,0);
    box(.65,.07,.08,metal,0,1.86,1.05);box(.42,.07,.1,dark,0,1.93,1.05);
    mesh(new THREE.SphereGeometry(.19,24,16),lamp,0,1.73,1.37).scale.set(1,.8,.5);
    cylinder(.08,.11,1.25,metal,.28,.93,-1.04,Math.PI/2,Math.PI/2); // exhaust
    box(.32,.1,.45,dark,0,1.03,-1.3); // rear mudguard
    box(.12,.1,.18,lamp,0,1.24,-1.5);
  } else {
    const suv=/creta|nexon|scorpio|suv/.test(modelName), sedan=/city|sedan/.test(modelName);
    const length=suv?4.65:4.25, width=suv?2.18:2.05, bodyY=suv?1.02:.82, cabinY=suv?1.66:1.43;
    box(width,.48,length,paint,0,bodyY,0);
    box(width*.88,.68,length*.48,paint,0,cabinY,-.28);
    box(width*.79,.5,length*.43,glass,0,cabinY+.02,-.28);
    box(width,.18,1.08,paint,0,bodyY+.18,length*.39);
    box(width,.16,.9,paint,0,bodyY+.14,-length*.42);
    box(width+.08,.12,length-.2,dark,0,.55,0);
    const axle=sedan?1.42:1.48, radius=suv?.52:.46;
    wheels=[wheel(-width*.51,axle,radius),wheel(width*.51,axle,radius),wheel(-width*.51,-axle,radius),wheel(width*.51,-axle,radius)];
    box(.34,.14,.08,lamp,-.72,.95,length*.5);box(.34,.14,.08,lamp,.72,.95,length*.5);
    box(.34,.13,.08,new THREE.MeshStandardMaterial({color:0x9d4338,emissive:0x3b100b}),-.72,.92,-length*.5);box(.34,.13,.08,new THREE.MeshStandardMaterial({color:0x9d4338,emissive:0x3b100b}),.72,.92,-length*.5);
    box(.18,.1,.24,dark,0,.58,length*.5);
  }
  const ground=mesh(new THREE.CircleGeometry(4.5,64),new THREE.MeshBasicMaterial({color:0x263a36,transparent:true,opacity:.45}),0,.015,0);ground.rotation.x=-Math.PI/2;
  const grid=new THREE.GridHelper(9,32,0x597365,0x2d403b);grid.position.y=.02;scene.add(grid);
  const markerSpecs=isMotorcycle?[['Powertrain',.35,1.45,-.25],['Braking',.2,.55,1.65],['Suspension',-.25,.7,-1.45],['Electrical',-.3,1.45,.9],['Lighting',0,1.75,1.5]]:[['Powertrain',0,1.7,-.2],['Braking',1.25,.55,1.3],['Suspension',-1.25,.55,-1.3],['Electrical',-.9,1.15,1.8],['Lighting',.75,.9,2.3]];
  const markers=[]; markerSpecs.forEach(([name,x,y,z])=>{const m=mesh(new THREE.SphereGeometry(.085,16,16),new THREE.MeshBasicMaterial({color:0xd78b70}),x,y,z);markers.push(m);});
  let down=false,px=0,py=0,rx=-.22,ry=.38,zoom=1;
  canvas.addEventListener('pointerdown',e=>{down=true;px=e.clientX;py=e.clientY;canvas.setPointerCapture(e.pointerId)});
  canvas.addEventListener('pointermove',e=>{if(!down)return;ry+=(e.clientX-px)*.008;rx=Math.max(-.8,Math.min(.4,rx+(e.clientY-py)*.005));px=e.clientX;py=e.clientY;});
  canvas.addEventListener('pointerup',()=>down=false);canvas.addEventListener('pointercancel',()=>down=false);
  canvas.addEventListener('wheel',e=>{zoom=Math.max(.7,Math.min(1.6,zoom+e.deltaY*.0007));e.preventDefault()},{passive:false});
  const resize=()=>{const w=Math.max(1,canvas.clientWidth),h=Math.max(1,canvas.clientHeight);renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()};new ResizeObserver(resize).observe(canvas);resize();
  function animate(){requestAnimationFrame(animate);vehicle.rotation.y+=(ry-vehicle.rotation.y)*.06;vehicle.rotation.x+=(rx-vehicle.rotation.x)*.06;const d=(isMotorcycle?6.2:7.6)/zoom;camera.position.set(Math.sin(vehicle.rotation.y)*d,isMotorcycle?2.7:3.9,Math.cos(vehicle.rotation.y)*d);camera.lookAt(0,isMotorcycle?.95:.7,0);markers.forEach((m,i)=>m.scale.setScalar(1+Math.sin(Date.now()*.003+i)*.13));renderer.render(scene,camera)}animate();
  const descriptions={'all':['Complete platform','Choose a system to focus the catalogue references below.'],'Engine Parts':['Powertrain','Engine and drivetrain references. Confirm engine code and exact model configuration.'],'Brakes':['Braking system','Confirm disc or drum setup, caliper type and exact part code.'],'Suspension':['Suspension system','Check mounting points, axle position and suspension configuration.'],'Electrical':['Electrical system','Confirm voltage, connector and electrical specification.'],'Lighting':['Lighting system','Validate housing, connector, beam pattern and road approval.'],'Filters':['Filtration system','Match dimensions and filtration specification to the exact engine.']};
  const activateSystem=k=>{const tab=$(`.system-tab[data-system="${k}"]`)||$('.system-tab[data-system="all"]');if(tab)tab.click()};
  $('.system-tab')&&$('.system-tab').parentElement&&$('.system-tab').parentElement.querySelectorAll('.system-tab').forEach(b=>b.addEventListener('click',()=>{ $('.system-tab').parentElement.querySelectorAll('.system-tab').forEach(x=>x.classList.toggle('active',x===b));const k=b.dataset.system,d=descriptions[k]||descriptions.all;const readout=document.getElementById('systemReadout');readout.innerHTML=`<span class="readout-index">SYS / ${String($('.system-tab').parentElement.querySelectorAll('.system-tab').length).padStart(2,'0')}</span><div><strong>${d[0]}</strong><p>${d[1]}</p></div>`;$('#partsGrid>[data-category]')&&$('#partsGrid').querySelectorAll('[data-category]').forEach(card=>card.hidden=k!=='all'&&!card.dataset.category.toLowerCase().includes(k.toLowerCase()));}));
  $('.studio-hotspots')&&$('.studio-hotspots').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>activateSystem(b.dataset.system)));
  let mode='standard';$$('.studio-mode').length&&$$('.studio-mode').forEach(b=>b.addEventListener('click',()=>{mode=b.dataset.view;$$('.studio-mode').forEach(x=>x.classList.toggle('active',x===b));vehicle.traverse(o=>{if(!o.isMesh)return;if(!o.userData.baseMaterial)o.userData.baseMaterial=o.material;o.material=mode==='wireframe'?o.userData.baseMaterial.clone():o.userData.baseMaterial;if(mode==='wireframe'){o.material.wireframe=true;o.material.transparent=true;o.material.opacity=.25;}});}));
  $('#resetVehicle')?.addEventListener('click',()=>{ry=.38;rx=-.22;zoom=1;mode='standard';$$('.studio-mode').forEach(x=>x.classList.toggle('active',x.dataset.view==='standard'));vehicle.traverse(o=>{if(o.isMesh&&o.userData.baseMaterial)o.material=o.userData.baseMaterial;});});
})();
