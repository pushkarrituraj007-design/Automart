USE automart;

INSERT IGNORE INTO brands (brand_id, name, brand_type, official_url, verified) VALUES
(1,'Bosch','AFTERMARKET','https://www.boschaftermarket.com/',FALSE),
(2,'Denso','AFTERMARKET','https://www.denso.com/',FALSE),
(3,'Example Genuine Parts','OEM',NULL,FALSE),
(4,'NGK','AFTERMARKET','https://www.ngkntk.com/',FALSE),
(5,'Monroe','AFTERMARKET','https://www.monroe.com/',FALSE);

INSERT IGNORE INTO part_categories (category_id, name) VALUES
(1,'Filters'),(2,'Braking'),(3,'Electrical'),(4,'Engine'),(5,'Suspension'),(6,'Cooling'),(7,'Body & Accessories');

INSERT IGNORE INTO parts
(part_id, part_name, brand_id, category_id, primary_part_number, classification, description, specification_summary, status)
VALUES
(1,'Engine Air Filter',1,1,'DEMO-AF-1001','AFTERMARKET','Illustrative catalogue record. Verify exact fitment before purchase.','Pleated filter media; dimensions vary by application.','ACTIVE'),
(2,'Oil Filter',2,1,'DEMO-OF-2040','AFTERMARKET','Illustrative catalogue record for demonstration only.','Thread and bypass specifications must be checked against application.','ACTIVE'),
(3,'Front Brake Pad Set',3,2,'DEMO-BP-3010','UNVERIFIED','Illustrative record; not represented as genuine or verified.','Axle position and caliper application must match.','ACTIVE'),
(4,'Spark Plug',4,3,'DEMO-SP-4012','AFTERMARKET','Illustrative catalogue record.','Heat range, reach and thread must match the engine.','ACTIVE'),
(5,'Shock Absorber',5,5,'DEMO-SA-5011','AFTERMARKET','Illustrative catalogue record.','Confirm axle, mounting and suspension configuration.','ACTIVE');

INSERT IGNORE INTO vehicles
(vehicle_id, make, model, model_year, variant, engine_or_trim, vehicle_type)
VALUES
(1,'Demo Motors','City Hatch',2022,'1.2 Petrol','1.2L Petrol','Car'),
(2,'Demo Motors','City Hatch',2023,'1.2 Petrol','1.2L Petrol','Car'),
(3,'Sample Auto','Urban Compact',2021,'1.0 Turbo','1.0L Turbo','Car'),
(4,'Sample Moto','Commuter 125',2023,'Standard','125cc','Motorcycle');

INSERT IGNORE INTO part_fitments
(fitment_id, part_id, vehicle_id, position_or_notes, fitment_status, evidence_source, verified)
VALUES
(1,1,1,'Engine air intake','POSSIBLE','Demo seed mapping; not verified',FALSE),
(2,2,1,'Engine lubrication','POSSIBLE','Demo seed mapping; not verified',FALSE),
(3,3,1,'Front axle','UNKNOWN','Demo seed mapping; not verified',FALSE),
(4,4,4,'Engine ignition','POSSIBLE','Demo seed mapping; not verified',FALSE),
(5,5,3,'Front suspension','UNKNOWN','Demo seed mapping; not verified',FALSE);

INSERT IGNORE INTO suppliers
(supplier_id, name, location, website_url, verified, status)
VALUES
(1,'Example Parts Supplier','Demo location','https://example.com/',FALSE,'ACTIVE'),
(2,'Sample Auto Spares','Demo location','https://example.org/',FALSE,'ACTIVE');

INSERT IGNORE INTO supplier_listings
(listing_id, part_id, supplier_id, source_url, availability, listing_status, last_checked_at)
VALUES
(1,1,1,'https://example.com/','UNKNOWN','ACTIVE',NOW()),
(2,2,1,'https://example.com/','UNKNOWN','ACTIVE',NOW()),
(3,3,2,'https://example.org/','UNKNOWN','ACTIVE',NOW()),
(4,4,2,'https://example.org/','UNKNOWN','ACTIVE',NOW()),
(5,5,1,'https://example.com/','UNKNOWN','ACTIVE',NOW());

INSERT INTO price_observations (listing_id, amount, currency, price_type, region, observed_at, notes)
SELECT x.listing_id, x.amount, 'INR', 'ESTIMATE', 'Demo only', NOW(), 'Fictional demo price; not a real quote'
FROM (
  SELECT 1 AS listing_id, 650.00 AS amount UNION ALL
  SELECT 2, 420.00 UNION ALL
  SELECT 3, 1450.00 UNION ALL
  SELECT 4, 280.00 UNION ALL
  SELECT 5, 2200.00
) x
WHERE NOT EXISTS (
  SELECT 1 FROM price_observations p WHERE p.listing_id = x.listing_id AND p.notes = 'Fictional demo price; not a real quote'
);
