CREATE DATABASE IF NOT EXISTS automart
  CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE automart;

CREATE TABLE IF NOT EXISTS brands (
  brand_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  brand_type ENUM('OEM','AFTERMARKET','DISTRIBUTOR','UNKNOWN') NOT NULL DEFAULT 'UNKNOWN',
  official_url VARCHAR(500),
  verified BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_brand_name (name)
);

CREATE TABLE IF NOT EXISTS part_categories (
  category_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  parent_category_id BIGINT NULL,
  CONSTRAINT fk_category_parent FOREIGN KEY (parent_category_id)
    REFERENCES part_categories(category_id) ON DELETE SET NULL,
  UNIQUE KEY uq_category_name (name)
);

CREATE TABLE IF NOT EXISTS parts (
  part_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  part_name VARCHAR(180) NOT NULL,
  brand_id BIGINT NOT NULL,
  category_id BIGINT NOT NULL,
  primary_part_number VARCHAR(100) NOT NULL,
  classification ENUM('GENUINE_OEM','OE_EQUIVALENT','AFTERMARKET','UNVERIFIED') NOT NULL DEFAULT 'UNVERIFIED',
  description TEXT,
  specification_summary VARCHAR(700),
  status ENUM('DRAFT','ACTIVE','ARCHIVED') NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_parts_brand FOREIGN KEY (brand_id) REFERENCES brands(brand_id),
  CONSTRAINT fk_parts_category FOREIGN KEY (category_id) REFERENCES part_categories(category_id),
  UNIQUE KEY uq_brand_part_number (brand_id, primary_part_number),
  INDEX idx_part_name (part_name),
  INDEX idx_part_number (primary_part_number),
  INDEX idx_part_status (status)
);

CREATE TABLE IF NOT EXISTS vehicles (
  vehicle_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  make VARCHAR(120) NOT NULL,
  model VARCHAR(120) NOT NULL,
  model_year INT,
  variant VARCHAR(120),
  engine_or_trim VARCHAR(150),
  vehicle_type VARCHAR(60) NOT NULL DEFAULT 'Car',
  UNIQUE KEY uq_vehicle (make, model, model_year, variant, engine_or_trim)
);

CREATE TABLE IF NOT EXISTS part_fitments (
  fitment_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  part_id BIGINT NOT NULL,
  vehicle_id BIGINT NOT NULL,
  position_or_notes VARCHAR(180),
  fitment_status ENUM('EXACT','POSSIBLE','UNKNOWN','INCOMPATIBLE') NOT NULL DEFAULT 'UNKNOWN',
  evidence_source VARCHAR(500),
  verified BOOLEAN NOT NULL DEFAULT FALSE,
  CONSTRAINT fk_fitment_part FOREIGN KEY (part_id) REFERENCES parts(part_id) ON DELETE CASCADE,
  CONSTRAINT fk_fitment_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id) ON DELETE CASCADE,
  UNIQUE KEY uq_part_vehicle_position (part_id, vehicle_id, position_or_notes)
);

CREATE TABLE IF NOT EXISTS suppliers (
  supplier_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(160) NOT NULL,
  location VARCHAR(180),
  website_url VARCHAR(500),
  contact_email VARCHAR(180),
  verified BOOLEAN NOT NULL DEFAULT FALSE,
  status ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  UNIQUE KEY uq_supplier_name (name)
);

CREATE TABLE IF NOT EXISTS supplier_listings (
  listing_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  part_id BIGINT NOT NULL,
  supplier_id BIGINT NOT NULL,
  source_url VARCHAR(700) NOT NULL,
  availability ENUM('IN_STOCK','OUT_OF_STOCK','ON_REQUEST','UNKNOWN') NOT NULL DEFAULT 'UNKNOWN',
  listing_status ENUM('ACTIVE','STALE','ARCHIVED') NOT NULL DEFAULT 'ACTIVE',
  last_checked_at DATETIME NULL,
  CONSTRAINT fk_listing_part FOREIGN KEY (part_id) REFERENCES parts(part_id),
  CONSTRAINT fk_listing_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
  INDEX idx_listing_part (part_id),
  INDEX idx_listing_status (listing_status)
);

CREATE TABLE IF NOT EXISTS price_observations (
  price_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  listing_id BIGINT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  price_type ENUM('LISTED','MRP','PROMOTIONAL','QUOTE','ESTIMATE','UNKNOWN') NOT NULL DEFAULT 'UNKNOWN',
  region VARCHAR(120),
  observed_at DATETIME NOT NULL,
  notes VARCHAR(500),
  CONSTRAINT fk_price_listing FOREIGN KEY (listing_id) REFERENCES supplier_listings(listing_id) ON DELETE CASCADE,
  INDEX idx_price_listing_date (listing_id, observed_at)
);

CREATE TABLE IF NOT EXISTS saved_parts (
  saved_part_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_key VARCHAR(120) NOT NULL,
  part_id BIGINT NOT NULL,
  saved_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_saved_part FOREIGN KEY (part_id) REFERENCES parts(part_id) ON DELETE CASCADE,
  UNIQUE KEY uq_saved_user_part (user_key, part_id)
);

CREATE TABLE IF NOT EXISTS audit_logs (
  audit_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  actor VARCHAR(120) NOT NULL,
  action_name VARCHAR(120) NOT NULL,
  record_type VARCHAR(100) NOT NULL,
  record_id BIGINT NULL,
  details VARCHAR(1000),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
