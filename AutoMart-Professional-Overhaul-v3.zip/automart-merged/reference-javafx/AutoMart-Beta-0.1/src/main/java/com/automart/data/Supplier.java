package com.automart.data;

public record Supplier(long id, String name, String location, String website, boolean verified, String status) {}
