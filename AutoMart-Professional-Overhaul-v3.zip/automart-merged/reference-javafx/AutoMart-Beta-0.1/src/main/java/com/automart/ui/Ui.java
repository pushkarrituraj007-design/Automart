package com.automart.ui;

import com.automart.data.*;
import javafx.animation.*;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.*;
import java.util.function.Consumer;

public class Ui {
    private final Stage stage;
    private final PartsRepository repo;
    private final BorderPane root = new BorderPane();
    private final StackPane contentHost = new StackPane();
    private final Set<Long> compareIds = new LinkedHashSet<>();
    private final String userKey = "local-demo-user";
    private String currentPage = "Home";
    private String selectedCategory = "All categories";
    private String selectedBrand = "All brands";
    private String searchText = "";
    private Vehicle selectedVehicle;
    private Label statusLabel;
    private Label compareCount;
    private final Map<String, Button> navButtons = new LinkedHashMap<>();

    private static final String[] ROTATING_WORDS = {"compatible", "genuine", "comparable", "right for you"};

    public Ui(Stage stage, PartsRepository repo) {
        this.stage = stage;
        this.repo = repo;
    }

    public Scene createScene() {
        root.getStyleClass().add("app-root");
        root.setTop(buildTopBar());
        root.setLeft(buildSidebar());
        contentHost.getStyleClass().add("content-host");
        root.setCenter(contentHost);
        root.setBottom(buildStatusBar());
        showPage("Home");
        Scene scene = new Scene(root, 1440, 900);
        scene.getStylesheets().add(Objects.requireNonNull(
                getClass().getResource("/styles.css")).toExternalForm());
        return scene;
    }

    private Node buildTopBar() {
        HBox bar = new HBox(18);
        bar.getStyleClass().add("topbar");
        bar.setAlignment(Pos.CENTER_LEFT);
        Label logoMark = new Label("A");
        logoMark.getStyleClass().add("logo-mark");
        VBox brand = new VBox(0, new Label("AutoMart"), new Label("PARTS INTELLIGENCE"));
        brand.getStyleClass().add("brand-lockup");
        HBox logo = new HBox(10, logoMark, brand);
        logo.setAlignment(Pos.CENTER_LEFT);
        Label appTag = new Label("BETA 0.1");
        appTag.getStyleClass().add("tiny-pill");
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
        TextField globalSearch = new TextField();
        globalSearch.setPromptText("Search parts, brands or part numbers…");
        globalSearch.getStyleClass().add("global-search");
        globalSearch.setPrefWidth(340);
        globalSearch.setOnAction(e -> { searchText = globalSearch.getText(); showPage("Find Parts"); });
        Button search = secondaryButton("Search", () -> { searchText = globalSearch.getText(); showPage("Find Parts"); });
        Button garage = secondaryButton("♡  My Garage", () -> showPage("My Garage"));
        Button compare = secondaryButton("⇄  Compare", () -> showPage("Compare"));
        compareCount = new Label("0");
        compareCount.getStyleClass().add("count-pill");
        HBox compareWrap = new HBox(6, compare, compareCount);
        compareWrap.setAlignment(Pos.CENTER);
        bar.getChildren().addAll(logo, appTag, spacer, globalSearch, search, compareWrap, garage);
        return bar;
    }

    private Node buildSidebar() {
        VBox side = new VBox(8);
        side.getStyleClass().add("sidebar");
        Label section = new Label("WORKSPACE");
        section.getStyleClass().add("section-label");
        side.getChildren().add(section);
        addNav(side,"Home","⌂","Overview");
        addNav(side,"Find Parts","◈","DISCOVER");
        addNav(side,"My Vehicle","⌁",null);
        addNav(side,"Compare","⇄",null);
        addNav(side,"My Garage","♡",null);
        addNav(side,"OEMs & Brands","◇","NETWORK");
        addNav(side,"Suppliers","▦",null);
        Region spacer = new Region(); VBox.setVgrow(spacer,Priority.ALWAYS);
        Label adminLabel = new Label("MANAGEMENT");
        adminLabel.getStyleClass().add("section-label");
        side.getChildren().addAll(spacer, adminLabel);
        addNav(side,"Admin Control","⚙",null);
        Label hint = new Label("Built for better\nparts decisions.");
        hint.getStyleClass().add("sidebar-hint");
        side.getChildren().add(hint);
        return side;
    }

    private void addNav(VBox side, String page, String icon, String section) {
        if (section != null) {
            Label lbl = new Label(section);
            lbl.getStyleClass().add("section-label");
            side.getChildren().add(lbl);
        }
        Button b = new Button(icon + "    " + page);
        b.setMaxWidth(Double.MAX_VALUE);
        b.setAlignment(Pos.CENTER_LEFT);
        b.getStyleClass().add("nav-button");
        b.setOnAction(e -> showPage(page));
        navButtons.put(page,b);
        side.getChildren().add(b);
    }

    private Node buildStatusBar() {
        HBox status = new HBox(10);
        status.getStyleClass().add("statusbar");
        status.setAlignment(Pos.CENTER_LEFT);
        CircleDot dot = new CircleDot(repo.isDatabaseConnected());
        statusLabel = new Label(repo.isDatabaseConnected() ? "MySQL connected" : "Demo mode · session-only changes");
        statusLabel.getStyleClass().add("status-text");
        Region spacer = new Region(); HBox.setHgrow(spacer,Priority.ALWAYS);
        Label note = new Label("Sample catalogue data · verify fitment and pricing before real-world use");
        note.getStyleClass().add("status-text");
        status.getChildren().addAll(dot.node, statusLabel, spacer, note);
        return status;
    }

    private static class CircleDot {
        Node node;
        CircleDot(boolean live) {
            javafx.scene.shape.Circle c = new javafx.scene.shape.Circle(4, live ? Color.web("#50D6A2") : Color.web("#E7B15C"));
            node = c;
        }
    }

    public void showPage(String page) {
        currentPage = page;
        navButtons.forEach((name,button) -> {
            button.getStyleClass().remove("nav-active");
            if (name.equals(page)) button.getStyleClass().add("nav-active");
        });
        Node node = switch (page) {
            case "Home" -> homePage();
            case "Find Parts" -> cataloguePage();
            case "My Vehicle" -> vehiclePage();
            case "Compare" -> comparePage();
            case "My Garage" -> garagePage();
            case "OEMs & Brands" -> brandsPage();
            case "Suppliers" -> suppliersPage();
            case "Admin Control" -> adminPage();
            default -> homePage();
        };
        contentHost.getChildren().setAll(node);
        node.setOpacity(0);
        FadeTransition ft = new FadeTransition(Duration.millis(220), node);
        ft.setFromValue(0); ft.setToValue(1); ft.play();
    }

    private Node homePage() {
        VBox page = pageContainer();
        HBox hero = new HBox(24);
        hero.getStyleClass().add("hero");
        VBox left = new VBox(18);
        left.setAlignment(Pos.CENTER_LEFT);
        Label eyebrow = new Label("THE AUTOMOTIVE PARTS MARKETPLACE");
        eyebrow.getStyleClass().add("eyebrow");
        Label headline = new Label("Every part has a fit.");
        headline.getStyleClass().add("hero-title");
        HBox rotatingLine = new HBox(8);
        rotatingLine.setAlignment(Pos.CENTER_LEFT);
        Label prefix = new Label("Find yours. Make it");
        prefix.getStyleClass().add("hero-subtitle");
        Label rotating = new Label(ROTATING_WORDS[0]);
        rotating.getStyleClass().add("rotating-word");
        rotatingLine.getChildren().addAll(prefix,rotating);
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(2.2), e -> {
            int next = (Arrays.asList(ROTATING_WORDS).indexOf(rotating.getText()) + 1) % ROTATING_WORDS.length;
            FadeTransition out = new FadeTransition(Duration.millis(170),rotating);
            out.setToValue(0);
            out.setOnFinished(ev -> {
                rotating.setText(ROTATING_WORDS[next]);
                FadeTransition in = new FadeTransition(Duration.millis(240),rotating);
                in.setFromValue(0); in.setToValue(1); in.play();
            });
            out.play();
        }));
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
        Label body = new Label("Discover parts by vehicle, part number or manufacturer.\nCompare options, understand pricing and source with confidence.");
        body.getStyleClass().add("hero-body");
        body.setWrapText(true);
        TextField search = new TextField(searchText);
        search.setPromptText("Try “oil filter”, “brake pad” or a part number");
        search.getStyleClass().add("hero-search");
        search.setOnAction(e -> { searchText = search.getText(); showPage("Find Parts"); });
        Button explore = primaryButton("Explore parts  →", () -> { searchText = search.getText(); showPage("Find Parts"); });
        Button byVehicle = secondaryButton("Find parts for my vehicle", () -> showPage("My Vehicle"));
        HBox actions = new HBox(10,explore,byVehicle);
        actions.setAlignment(Pos.CENTER_LEFT);
        left.getChildren().addAll(eyebrow,headline,rotatingLine,body,search,actions);
        left.setPrefWidth(620);
        VBox right = new VBox(12);
        right.getStyleClass().add("hero-visual");
        Label visualLabel = new Label("PARTS, NOT GUESSWORK");
        visualLabel.getStyleClass().add("eyebrow");
        Label bigIcon = new Label("◈");
        bigIcon.getStyleClass().add("hero-symbol");
        Label visualTitle = new Label("Fitment-first\nparts discovery");
        visualTitle.getStyleClass().add("hero-visual-title");
        HBox tags = new HBox(8, pill("Part number"), pill("Vehicle fitment"), pill("Source-aware price"));
        tags.setAlignment(Pos.CENTER_LEFT);
        right.getChildren().addAll(visualLabel,bigIcon,visualTitle,tags);
        HBox.setHgrow(left,Priority.ALWAYS); HBox.setHgrow(right,Priority.ALWAYS);
        hero.getChildren().addAll(left,right);

        Label sectionTitle = sectionTitle("Discover by category","Start with the system you need to repair or maintain.");
        GridPane categories = new GridPane(); categories.setHgap(14); categories.setVgap(14);
        String[][] cats = {{"Filters","Oil, air and cabin filters","◉"},{"Braking","Pads, discs and brake parts","◎"},{"Electrical","Plugs, sensors and lighting","ϟ"},{"Suspension","Shocks, joints and bearings","⌁"}};
        for (int i=0;i<cats.length;i++) {
            final String cat = cats[i][0];
            VBox card = categoryCard(cats[i][2],cats[i][0],cats[i][1],()->{selectedCategory=cat;showPage("Find Parts");});
            categories.add(card,i%2,i/2);
            GridPane.setHgrow(card,Priority.ALWAYS);
        }
        for(int i=0;i<2;i++) GridPane.setHgrow(categories.getChildren().get(i),Priority.ALWAYS);
        Label featuredTitle = sectionTitle("Parts people look for","Illustrative sample records · prices are fictional demo estimates.");
        HBox featured = new HBox(14);
        repo.allParts().stream().limit(3).map(this::partCard).forEach(featured.getChildren()::add);
        featured.getChildren().forEach(n->HBox.setHgrow(n,Priority.ALWAYS));
        page.getChildren().addAll(hero,sectionTitle,categories,featuredTitle,featured);
        return scroll(page);
    }

    private Node cataloguePage() {
        VBox page = pageContainer();
        page.getChildren().add(pageHeader("Find parts","Search across brands, part numbers and categories."));
        HBox controls = new HBox(10);
        TextField search = new TextField(searchText); search.setPromptText("Part name, brand or part number"); search.getStyleClass().add("field");
        ComboBox<String> cat = new ComboBox<>(); cat.getItems().setAll(repo.allCategories()); cat.setValue(repo.allCategories().contains(selectedCategory)?selectedCategory:"All categories");
        ComboBox<String> brand = new ComboBox<>(); brand.getItems().setAll(repo.allBrands()); brand.setValue(repo.allBrands().contains(selectedBrand)?selectedBrand:"All brands");
        Button reset = secondaryButton("Reset",()->{searchText="";selectedCategory="All categories";selectedBrand="All brands";showPage("Find Parts");});
        FlowPane results = new FlowPane(14,14); results.setPrefWrapLength(1000);
        controls.getChildren().addAll(search,cat,brand,reset);
        search.setOnAction(e->{searchText=search.getText();selectedCategory=cat.getValue();selectedBrand=brand.getValue();refreshCatalogueResults(results,search.getText(),cat.getValue(),brand.getValue());});
        cat.setOnAction(e->{selectedCategory=cat.getValue();refreshCatalogueResults(results,search.getText(),cat.getValue(),brand.getValue());});
        brand.setOnAction(e->{selectedBrand=brand.getValue();refreshCatalogueResults(results,search.getText(),cat.getValue(),brand.getValue());});
        HBox.setHgrow(search,Priority.ALWAYS);
        refreshCatalogueResults(results,search.getText(),cat.getValue(),brand.getValue());
        Label count = new Label(repo.findParts(search.getText(),cat.getValue(),brand.getValue()).size()+" parts shown");
        count.getStyleClass().add("muted");
        page.getChildren().addAll(controls,count,results);
        return scroll(page);
    }

    private void refreshCatalogueResults(FlowPane results,String query,String category,String brand) {
        results.getChildren().clear();
        List<Part> parts = repo.findParts(query,category,brand);
        if(parts.isEmpty()) {
            VBox empty = new VBox(8,new Label("No parts found"),new Label("Try another part number, brand or category."));
            empty.getStyleClass().add("empty-state"); results.getChildren().add(empty); return;
        }
        for(Part p:parts) results.getChildren().add(partCard(p));
    }

    private Node vehiclePage() {
        VBox page=pageContainer();
        page.getChildren().add(pageHeader("Find parts for your vehicle","Choose a vehicle to narrow the catalogue to recorded fitment matches."));
        ComboBox<Vehicle> vehicles=new ComboBox<>();
        vehicles.getItems().setAll(repo.allVehicles()); vehicles.setPromptText("Select make, model, year and variant");
        if(selectedVehicle!=null) vehicles.setValue(selectedVehicle);
        vehicles.setMaxWidth(620); vehicles.getStyleClass().add("field");
        Label note=new Label("Demo fitment data is illustrative and unverified. Confirm exact application before ordering.");
        note.getStyleClass().add("warning-note");
        FlowPane results=new FlowPane(14,14);
        Runnable refresh=()->{
            results.getChildren().clear();
            Vehicle v=vehicles.getValue(); selectedVehicle=v;
            if(v==null){results.getChildren().add(new Label("Select a vehicle to see mapped parts."));return;}
            List<Part> list=repo.partsForVehicle(v.id());
            if(list.isEmpty()){results.getChildren().add(new Label("No mapped parts yet. Try another vehicle or add fitment data in a later sprint."));return;}
            list.forEach(p->results.getChildren().add(partCard(p)));
        };
        vehicles.setOnAction(e->refresh.run());
        if(selectedVehicle!=null) refresh.run();
        VBox vehiclePanel=new VBox(12,new Label("YOUR VEHICLE"),vehicles,note);
        vehiclePanel.getStyleClass().add("glass-panel");
        page.getChildren().addAll(vehiclePanel,sectionTitle("Compatible parts","Only mapped demo matches are shown here."),results);
        return scroll(page);
    }

    private Node comparePage() {
        VBox page=pageContainer();
        page.getChildren().add(pageHeader("Compare parts","Compare part identity, classification, price and source side by side."));
        Label helper=new Label("Select Compare on up to four product cards. Fitment and specifications need verified data for a meaningful real-world comparison.");
        helper.getStyleClass().add("muted"); helper.setWrapText(true);
        HBox actions=new HBox(10,secondaryButton("Clear comparison",()->{compareIds.clear();updateCompareCount();showPage("Compare");}),
                primaryButton("Add parts from catalogue",()->showPage("Find Parts")));
        FlowPane cards=new FlowPane(14,14);
        List<Part> selected=repo.allParts().stream().filter(p->compareIds.contains(p.id())).toList();
        if(selected.isEmpty()) {
            VBox empty=new VBox(10,new Label("Your comparison is empty"),new Label("Open Find Parts and select Compare on two or more products."));
            empty.getStyleClass().add("empty-state"); cards.getChildren().add(empty);
        } else {
            for(Part p:selected) cards.getChildren().add(partCard(p));
            GridPane table=new GridPane(); table.getStyleClass().add("compare-table"); table.setHgap(10);table.setVgap(10);
            String[] labels={"Part","Manufacturer","Part number","Category","Classification","Displayed price","Price type","Source","Compatibility"};
            for(int r=0;r<labels.length;r++){
                Label l=new Label(labels[r]);l.getStyleClass().add("compare-label");table.add(l,0,r);
                for(int c=0;c<selected.size();c++){
                    Part p=selected.get(c);
                    String val=switch(r){case 0->p.name();case 1->p.brand();case 2->p.partNumber();case 3->p.category();case 4->p.classification();case 5->p.priceText();case 6->p.priceType();case 7->p.source();default->p.compatibility();};
                    Label cell=new Label(val==null?"Not available":val);cell.setWrapText(true);cell.getStyleClass().add("compare-cell");table.add(cell,c+1,r);
                }
            }
            page.getChildren().addAll(actions,cards,sectionTitle("Side-by-side specifications","Missing or unverified fields should not be interpreted as proof of equivalence."),table);
            return scroll(page);
        }
        page.getChildren().addAll(helper,actions,cards,sectionTitle("Available parts","Select items from the catalogue to start a comparison."));
        FlowPane available=new FlowPane(14,14);repo.allParts().forEach(p->available.getChildren().add(partCard(p)));
        page.getChildren().add(available);
        return scroll(page);
    }

    private Node garagePage() {
        VBox page=pageContainer();
        page.getChildren().add(pageHeader("My Garage","Your saved parts shortlist. Demo mode keeps changes for this session only."));
        List<Part> saved=repo.savedParts(userKey);
        if(saved.isEmpty()){
            VBox empty=new VBox(10,new Label("Your garage is ready"),new Label("Save parts from Find Parts to keep a shortlist here."),
                    primaryButton("Browse parts",()->showPage("Find Parts")));
            empty.getStyleClass().add("empty-state");page.getChildren().add(empty);
        } else {
            FlowPane cards=new FlowPane(14,14);
            for(Part p:saved){
                VBox wrapper=new VBox(8,partCard(p),secondaryButton("Remove from Garage",()->{repo.removeSavedPart(userKey,p.id());showPage("My Garage");}));
                cards.getChildren().add(wrapper);
            }
            page.getChildren().add(cards);
        }
        return scroll(page);
    }

    private Node brandsPage() {
        VBox page=pageContainer();
        page.getChildren().add(pageHeader("OEMs & brands","Explore manufacturers and their parts catalogues. Listing a brand does not imply endorsement."));
        GridPane grid=new GridPane();grid.setHgap(14);grid.setVgap(14);
        List<String> brands=repo.allBrands().stream().filter(s->!s.equals("All brands")).toList();
        for(int i=0;i<brands.size();i++){
            String brand=brands.get(i);
            VBox card=new VBox(10,new Label("◇"),new Label(brand),new Label(repo.allParts().stream().filter(p->p.brand().equals(brand)).count()+" sample parts"),
                    secondaryButton("View parts",()->{selectedBrand=brand;showPage("Find Parts");}));
            card.getStyleClass().add("brand-card");
            grid.add(card,i%3,i/3);GridPane.setHgrow(card,Priority.ALWAYS);
        }
        page.getChildren().add(grid);
        return scroll(page);
    }

    private Node suppliersPage() {
        VBox page=pageContainer();
        page.getChildren().add(pageHeader("Suppliers","Source links and supplier information. Sample suppliers are not verified."));
        GridPane grid=new GridPane();grid.setHgap(14);grid.setVgap(14);
        List<Supplier> suppliers=repo.allSuppliers();
        for(int i=0;i<suppliers.size();i++){
            Supplier s=suppliers.get(i);
            VBox card=new VBox(10,new Label("▦"),new Label(s.name()),new Label(s.location()==null?"Location not provided":s.location()),
                    new Label(s.verified()?"Verified supplier":"Not verified"),new Label(s.website()==null?"No website":s.website()),
                    secondaryButton("View supplier parts",()->{showPage("Find Parts");}));
            card.getStyleClass().add("brand-card");
            grid.add(card,i%3,i/3);GridPane.setHgrow(card,Priority.ALWAYS);
        }
        page.getChildren().add(grid);
        return scroll(page);
    }

    private Node adminPage() {
        VBox page=pageContainer();
        page.getChildren().add(pageHeader("Admin Control Center","Beta controls for the sample catalogue. Authentication and role enforcement are Sprint 2."));
        GridPane kpis=new GridPane();kpis.setHgap(12);kpis.setVgap(12);
        kpis.add(kpi("PARTS",String.valueOf(repo.allParts().size()),"Catalogue records"),0,0);
        kpis.add(kpi("BRANDS",String.valueOf(repo.allBrands().size()-1),"Listed brands"),1,0);
        kpis.add(kpi("VEHICLES",String.valueOf(repo.allVehicles().size()),"Fitment reference"),2,0);
        kpis.add(kpi("DATABASE",repo.isDatabaseConnected()?"Connected":"Demo mode","Storage status"),3,0);
        HBox actions=new HBox(10,primaryButton("+ Add part",this::showAddPartDialog),
                secondaryButton("Refresh",()->showPage("Admin Control")),secondaryButton("Open data-quality view",()->showDataQuality(page)));
        TableView<Part> table=new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        table.getStyleClass().add("data-table");
        TableColumn<Part,String> name=new TableColumn<>("Part");name.setCellValueFactory(d->new javafx.beans.property.SimpleStringProperty(d.getValue().name()));
        TableColumn<Part,String> brand=new TableColumn<>("Brand");brand.setCellValueFactory(d->new javafx.beans.property.SimpleStringProperty(d.getValue().brand()));
        TableColumn<Part,String> pn=new TableColumn<>("Part number");pn.setCellValueFactory(d->new javafx.beans.property.SimpleStringProperty(d.getValue().partNumber()));
        TableColumn<Part,String> cls=new TableColumn<>("Classification");cls.setCellValueFactory(d->new javafx.beans.property.SimpleStringProperty(d.getValue().classification()));
        TableColumn<Part,String> price=new TableColumn<>("Price");price.setCellValueFactory(d->new javafx.beans.property.SimpleStringProperty(d.getValue().priceText()));
        table.getColumns().addAll(name,brand,pn,cls,price);table.getItems().setAll(repo.allParts());table.setPrefHeight(360);
        page.getChildren().addAll(kpis,actions,sectionTitle("Catalogue records","Admin changes in demo mode are temporary; MySQL mode persists records."),table);
        return scroll(page);
    }

    private void showDataQuality(VBox page) {
        Alert a=new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Data quality");a.setHeaderText("Beta data-quality checks");
        long unknown=repo.allParts().stream().filter(p->p.compatibility()==null||p.compatibility().contains("Unknown")||p.compatibility().contains("Not mapped")).count();
        a.setContentText("Parts requiring fitment review: "+unknown+"\n\nNext sprint: missing-field report, duplicate part-number checks, stale price detection and CSV validation.");
        a.showAndWait();
    }

    private void showAddPartDialog() {
        Dialog<ButtonType> dialog=new Dialog<>();dialog.setTitle("Add part");dialog.setHeaderText("Create a catalogue record");
        ButtonType saveType=new ButtonType("Save part",ButtonBar.ButtonData.OK_DONE);dialog.getDialogPane().getButtonTypes().addAll(saveType,ButtonType.CANCEL);
        TextField name=new TextField();name.setPromptText("Part name");
        TextField brand=new TextField();brand.setPromptText("Brand (must already exist in MySQL)");
        TextField category=new TextField();category.setPromptText("Category (must already exist in MySQL)");
        TextField pn=new TextField();pn.setPromptText("Unique part number");
        ComboBox<String> cls=new ComboBox<>();cls.getItems().setAll("GENUINE_OEM","OE_EQUIVALENT","AFTERMARKET","UNVERIFIED");cls.setValue("UNVERIFIED");
        TextField specs=new TextField();specs.setPromptText("Short specification summary");
        TextArea desc=new TextArea();desc.setPromptText("Description");desc.setPrefRowCount(3);
        GridPane form=new GridPane();form.setHgap(10);form.setVgap(10);
        form.addRow(0,new Label("Name"),name);form.addRow(1,new Label("Brand"),brand);form.addRow(2,new Label("Category"),category);
        form.addRow(3,new Label("Part number"),pn);form.addRow(4,new Label("Classification"),cls);form.addRow(5,new Label("Specs"),specs);form.addRow(6,new Label("Description"),desc);
        dialog.getDialogPane().setContent(form);
        dialog.setResultConverter(bt->bt==saveType?saveType:null);
        dialog.showAndWait().ifPresent(result->{
            if(result==saveType){
                if(name.getText().isBlank()||brand.getText().isBlank()||category.getText().isBlank()||pn.getText().isBlank()){
                    alert(Alert.AlertType.WARNING,"Required fields","Name, brand, category and part number are required.");return;
                }
                try{
                    repo.addPart(name.getText().trim(),brand.getText().trim(),category.getText().trim(),pn.getText().trim(),cls.getValue(),desc.getText(),specs.getText());
                    alert(Alert.AlertType.INFORMATION,"Saved","Part record saved. In demo mode it will be kept only until the app closes.");
                    showPage("Admin Control");
                }catch(Exception ex){alert(Alert.AlertType.ERROR,"Could not save part",ex.getMessage());}
            }
        });
    }

    private VBox partCard(Part p) {
        VBox card=new VBox(10);
        card.getStyleClass().add("part-card");
        card.setPrefWidth(265);card.setMinWidth(240);card.setMaxWidth(340);
        StackPane art=new StackPane();
        art.getStyleClass().add("product-art");
        Label symbol=new Label(symbolFor(p.category()));symbol.getStyleClass().add("product-symbol");
        Label cat=new Label(p.category().toUpperCase(Locale.ROOT));cat.getStyleClass().add("product-category");
        StackPane.setAlignment(cat,Pos.TOP_LEFT);StackPane.setMargin(cat,new Insets(12));
        art.getChildren().addAll(symbol,cat);
        HBox top=new HBox(8,pill(p.classification().replace('_',' ')));Region sp=new Region();HBox.setHgrow(sp,Priority.ALWAYS);
        Label id=new Label("#"+p.id());id.getStyleClass().add("muted");top.getChildren().addAll(sp,id);
        Label name=new Label(p.name());name.getStyleClass().add("part-title");name.setWrapText(true);
        Label brand=new Label(p.brand()+" · "+p.partNumber());brand.getStyleClass().add("muted");brand.setWrapText(true);
        Label price=new Label(p.priceText());price.getStyleClass().add("price-text");
        Label source=new Label(p.priceType()+" · "+p.source());source.getStyleClass().add("tiny-muted");source.setWrapText(true);
        Label compat=new Label(p.compatibility()==null?"Fitment not mapped":p.compatibility());compat.getStyleClass().add("compat-note");compat.setWrapText(true);
        HBox actions=new HBox(7);
        Button save=secondaryButton("♡ Save",()->{repo.savePart(userKey,p.id());save.setText("✓ Saved");});
        Button compare=secondaryButton(compareIds.contains(p.id())?"✓ Selected":"⇄ Compare",()->{
            if(compareIds.contains(p.id()))compareIds.remove(p.id());
            else if(compareIds.size()<4)compareIds.add(p.id());
            else {alert(Alert.AlertType.INFORMATION,"Comparison full","Compare up to four parts at a time.");return;}
            updateCompareCount();compare.setText(compareIds.contains(p.id())?"✓ Selected":"⇄ Compare");
        });
        Button details=secondaryButton("Details",()->showPartDetails(p));
        actions.getChildren().addAll(save,compare,details);
        card.getChildren().addAll(art,top,name,brand,price,source,compat,actions);
        card.setOnMouseEntered(e->card.getStyleClass().add("part-card-hover"));
        card.setOnMouseExited(e->card.getStyleClass().remove("part-card-hover"));
        return card;
    }

    private void showPartDetails(Part p) {
        Dialog<ButtonType> d=new Dialog<>();d.setTitle(p.name());d.setHeaderText(p.brand()+" · "+p.partNumber());
        d.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        VBox box=new VBox(10);
        box.getChildren().addAll(new Label("Category: "+p.category()),new Label("Classification: "+p.classification()),
                new Label("Displayed price: "+p.priceText()+" ("+p.priceType()+")"),new Label("Source: "+p.source()),
                new Label("Source URL: "+(p.sourceUrl()==null||p.sourceUrl().isBlank()?"Not provided":p.sourceUrl())),
                new Label("Availability: "+p.availability()),new Label("Fitment: "+p.compatibility()),new Label("Specifications: "+p.specs()));
        box.setPrefWidth(520);box.setPadding(new Insets(8));d.getDialogPane().setContent(box);d.showAndWait();
    }

    private VBox pageContainer() { VBox b=new VBox(22);b.getStyleClass().add("page-container");b.setPadding(new Insets(28,34,34,34));return b; }
    private Node scroll(Node n) { ScrollPane s=new ScrollPane(n);s.setFitToWidth(true);s.getStyleClass().add("page-scroll");return s; }
    private VBox pageHeader(String title,String subtitle) {
        Label t=new Label(title);t.getStyleClass().add("page-title");
        Label sub=new Label(subtitle);sub.getStyleClass().add("page-subtitle");sub.setWrapText(true);
        return new VBox(6,t,sub);
    }
    private VBox sectionTitle(String title,String sub) {
        Label t=new Label(title);t.getStyleClass().add("section-title");
        Label s=new Label(sub);s.getStyleClass().add("page-subtitle");s.setWrapText(true);
        return new VBox(4,t,s);
    }
    private VBox categoryCard(String symbol,String title,String sub,Runnable action) {
        Button b=new Button("Explore →");b.getStyleClass().add("text-button");b.setOnAction(e->action.run());
        Label icon=new Label(symbol);icon.getStyleClass().add("category-symbol");
        Label t=new Label(title);t.getStyleClass().add("card-title");
        Label s=new Label(sub);s.getStyleClass().add("muted");s.setWrapText(true);
        VBox box=new VBox(10,icon,t,s,b);box.getStyleClass().add("category-card");box.setMinWidth(240);return box;
    }
    private VBox kpi(String label,String value,String sub) {
        Label l=new Label(label);l.getStyleClass().add("section-label");
        Label v=new Label(value);v.getStyleClass().add("kpi-value");
        Label s=new Label(sub);s.getStyleClass().add("muted");
        VBox b=new VBox(8,l,v,s);b.getStyleClass().add("kpi-card");GridPane.setHgrow(b,Priority.ALWAYS);return b;
    }
    private Label pill(String text) { Label l=new Label(text);l.getStyleClass().add("pill");return l; }
    private String symbolFor(String cat) {
        if(cat==null)return "◈";
        return switch(cat.toLowerCase(Locale.ROOT)){case "filters"->"◉";case "braking"->"◎";case "electrical"->"ϟ";case "suspension"->"⌁";case "engine"->"⚙";default->"◈";};
    }
    private Button primaryButton(String text,Runnable action) {
        Button b=new Button(text);b.getStyleClass().add("primary-button");b.setOnAction(e->action.run());return b;
    }
    private Button secondaryButton(String text,Runnable action) {
        Button b=new Button(text);b.getStyleClass().add("secondary-button");b.setOnAction(e->action.run());return b;
    }
    private void updateCompareCount() { if(compareCount!=null) compareCount.setText(String.valueOf(compareIds.size())); }
    private void alert(Alert.AlertType type,String title,String message) {
        Alert a=new Alert(type);a.setTitle(title);a.setHeaderText(null);a.setContentText(message);a.showAndWait();
    }
}
