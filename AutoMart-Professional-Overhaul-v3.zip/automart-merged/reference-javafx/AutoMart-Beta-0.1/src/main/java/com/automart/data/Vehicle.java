package com.automart.data;

public record Vehicle(long id, String make, String model, Integer year, String variant, String engine, String type) {
    @Override
    public String toString() {
        String y = year == null ? "" : " " + year;
        String v = variant == null || variant.isBlank() ? "" : " · " + variant;
        return make + " " + model + y + v;
    }
}
