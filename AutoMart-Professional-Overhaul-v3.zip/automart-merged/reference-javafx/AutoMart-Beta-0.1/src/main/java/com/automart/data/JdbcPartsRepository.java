package com.automart.data;

import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

public class JdbcPartsRepository implements PartsRepository {
    private final String url;
    private final String user;
    private final String password;
    private final DemoPartsRepository demo = new DemoPartsRepository();
    private boolean connected;

    public JdbcPartsRepository() {
        url = System.getenv("AUTOMART_DB_URL");
        user = System.getenv("AUTOMART_DB_USER");
        password = System.getenv("AUTOMART_DB_PASSWORD");
        connected = false;
        if (url != null && !url.isBlank() && user != null && password != null) {
            try (Connection ignored = connection()) {
                connected = true;
                System.out.println("AutoMart connected to MySQL.");
            } catch (Exception ex) {
                System.err.println("AutoMart MySQL unavailable; using demo mode: " + ex.getMessage());
            }
        } else {
            System.out.println("AutoMart database environment variables not set; using demo mode.");
        }
    }

    private Connection connection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    @Override public boolean isDatabaseConnected() { return connected; }

    @Override
    public List<Part> findParts(String query, String category, String brand) {
        if (!connected) return demo.findParts(query, category, brand);
        String sql = """
            SELECT p.part_id, p.part_name, b.name AS brand, c.name AS category,
                   p.primary_part_number, p.classification,
                   COALESCE((SELECT po.amount FROM price_observations po
                     JOIN supplier_listings sl ON sl.listing_id=po.listing_id
                     WHERE sl.part_id=p.part_id AND sl.listing_status='ACTIVE'
                     ORDER BY po.observed_at DESC LIMIT 1),0) AS price,
                   COALESCE((SELECT po.price_type FROM price_observations po
                     JOIN supplier_listings sl ON sl.listing_id=po.listing_id
                     WHERE sl.part_id=p.part_id AND sl.listing_status='ACTIVE'
                     ORDER BY po.observed_at DESC LIMIT 1),'UNKNOWN') AS price_type,
                   COALESCE((SELECT s.name FROM supplier_listings sl
                     JOIN suppliers s ON s.supplier_id=sl.supplier_id
                     WHERE sl.part_id=p.part_id AND sl.listing_status='ACTIVE'
                     LIMIT 1),'No source') AS source,
                   COALESCE((SELECT sl.source_url FROM supplier_listings sl
                     WHERE sl.part_id=p.part_id AND sl.listing_status='ACTIVE'
                     LIMIT 1),'') AS source_url,
                   COALESCE((SELECT sl.availability FROM supplier_listings sl
                     WHERE sl.part_id=p.part_id AND sl.listing_status='ACTIVE'
                     LIMIT 1),'UNKNOWN') AS availability,
                   COALESCE((SELECT GROUP_CONCAT(DISTINCT CONCAT(v.make,' ',v.model,' ',COALESCE(v.model_year,''),' · ',pf.fitment_status) SEPARATOR '; ')
                     FROM part_fitments pf JOIN vehicles v ON v.vehicle_id=pf.vehicle_id
                     WHERE pf.part_id=p.part_id),'No fitment data') AS compatibility,
                   COALESCE(p.specification_summary,'') AS specs
            FROM parts p JOIN brands b ON b.brand_id=p.brand_id
            JOIN part_categories c ON c.category_id=p.category_id
            WHERE p.status='ACTIVE'
              AND (?='' OR LOWER(CONCAT_WS(' ',p.part_name,p.primary_part_number,b.name,c.name,p.classification))
                    LIKE CONCAT('%',LOWER(?),'%'))
              AND (?='All categories' OR c.name=?)
              AND (?='All brands' OR b.name=?)
            ORDER BY p.part_name
            """;
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql)) {
            String q = query == null ? "" : query.trim();
            String cat = category == null ? "All categories" : category;
            String br = brand == null ? "All brands" : brand;
            ps.setString(1, q); ps.setString(2, q);
            ps.setString(3, cat); ps.setString(4, cat);
            ps.setString(5, br); ps.setString(6, br);
            try (ResultSet rs = ps.executeQuery()) {
                List<Part> out = new ArrayList<>();
                while (rs.next()) out.add(new Part(rs.getLong("part_id"), rs.getString("part_name"),
                        rs.getString("brand"), rs.getString("category"), rs.getString("primary_part_number"),
                        rs.getString("classification"), rs.getDouble("price"), rs.getString("price_type"),
                        rs.getString("source"), rs.getString("source_url"), rs.getString("availability"),
                        rs.getString("compatibility"), rs.getString("specs")));
                return out;
            }
        } catch (SQLException e) {
            System.err.println("Parts query failed; showing demo data: " + e.getMessage());
            connected = false;
            return demo.findParts(query, category, brand);
        }
    }

    @Override public List<Part> allParts() { return findParts("", "All categories", "All brands"); }

    @Override
    public List<Vehicle> allVehicles() {
        if (!connected) return demo.allVehicles();
        String sql = "SELECT vehicle_id,make,model,model_year,variant,engine_or_trim,vehicle_type FROM vehicles ORDER BY make,model,model_year";
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            List<Vehicle> list = new ArrayList<>();
            while (rs.next()) {
                int y = rs.getInt("model_year");
                list.add(new Vehicle(rs.getLong("vehicle_id"), rs.getString("make"), rs.getString("model"),
                        rs.wasNull() ? null : y, rs.getString("variant"), rs.getString("engine_or_trim"), rs.getString("vehicle_type")));
            }
            return list;
        } catch (SQLException e) { connected = false; return demo.allVehicles(); }
    }

    @Override
    public List<Part> partsForVehicle(long vehicleId) {
        if (!connected) return demo.partsForVehicle(vehicleId);
        String sql = """
            SELECT p.part_id,p.part_name,b.name AS brand,c.name AS category,p.primary_part_number,p.classification,
              COALESCE((SELECT po.amount FROM price_observations po JOIN supplier_listings sl ON sl.listing_id=po.listing_id
                WHERE sl.part_id=p.part_id ORDER BY po.observed_at DESC LIMIT 1),0) price,
              COALESCE((SELECT po.price_type FROM price_observations po JOIN supplier_listings sl ON sl.listing_id=po.listing_id
                WHERE sl.part_id=p.part_id ORDER BY po.observed_at DESC LIMIT 1),'UNKNOWN') price_type,
              COALESCE((SELECT s.name FROM supplier_listings sl JOIN suppliers s ON s.supplier_id=sl.supplier_id
                WHERE sl.part_id=p.part_id LIMIT 1),'No source') source,
              COALESCE((SELECT sl.source_url FROM supplier_listings sl WHERE sl.part_id=p.part_id LIMIT 1),'') source_url,
              COALESCE((SELECT sl.availability FROM supplier_listings sl WHERE sl.part_id=p.part_id LIMIT 1),'UNKNOWN') availability,
              pf.fitment_status compatibility, COALESCE(p.specification_summary,'') specs
            FROM part_fitments pf JOIN parts p ON p.part_id=pf.part_id
            JOIN brands b ON b.brand_id=p.brand_id JOIN part_categories c ON c.category_id=p.category_id
            WHERE pf.vehicle_id=? AND p.status='ACTIVE' AND pf.fitment_status IN ('EXACT','POSSIBLE')
            ORDER BY p.part_name
            """;
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, vehicleId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Part> out = new ArrayList<>();
                while (rs.next()) out.add(new Part(rs.getLong("part_id"), rs.getString("part_name"),
                        rs.getString("brand"), rs.getString("category"), rs.getString("primary_part_number"),
                        rs.getString("classification"), rs.getDouble("price"), rs.getString("price_type"),
                        rs.getString("source"), rs.getString("source_url"), rs.getString("availability"),
                        rs.getString("compatibility"), rs.getString("specs")));
                return out;
            }
        } catch (SQLException e) { connected = false; return demo.partsForVehicle(vehicleId); }
    }

    @Override
    public List<Supplier> allSuppliers() {
        if (!connected) return demo.allSuppliers();
        String sql = "SELECT supplier_id,name,location,website_url,verified,status FROM suppliers WHERE status='ACTIVE' ORDER BY name";
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            List<Supplier> list = new ArrayList<>();
            while (rs.next()) list.add(new Supplier(rs.getLong(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getBoolean(5),rs.getString(6)));
            return list;
        } catch (SQLException e) { connected = false; return demo.allSuppliers(); }
    }

    @Override public List<String> allBrands() {
        if (!connected) return demo.allBrands();
        return strings("SELECT name FROM brands ORDER BY name", "All brands");
    }

    @Override public List<String> allCategories() {
        if (!connected) return demo.allCategories();
        return strings("SELECT name FROM part_categories ORDER BY name", "All categories");
    }

    private List<String> strings(String sql, String first) {
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            List<String> values = new ArrayList<>(); values.add(first);
            while (rs.next()) values.add(rs.getString(1));
            return values;
        } catch (SQLException e) { connected = false; return List.of(first); }
    }

    @Override
    public void addPart(String name, String brand, String category, String partNumber, String classification,
                        String description, String specs) {
        if (!connected) { demo.addPart(name, brand, category, partNumber, classification, description, specs); return; }
        String sql = """
            INSERT INTO parts(part_name,brand_id,category_id,primary_part_number,classification,description,specification_summary,status)
            SELECT ?,b.brand_id,c.category_id,?,?,?,?,'ACTIVE'
            FROM brands b CROSS JOIN part_categories c WHERE b.name=? AND c.name=?
            """;
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1,name); ps.setString(2,partNumber); ps.setString(3,classification);
            ps.setString(4,description); ps.setString(5,specs); ps.setString(6,brand); ps.setString(7,category);
            int rows = ps.executeUpdate();
            if (rows == 0) throw new SQLException("Brand or category not found. Add them in MySQL first.");
            try (PreparedStatement audit = c.prepareStatement(
                    "INSERT INTO audit_logs(actor,action_name,record_type,details) VALUES('local-admin','CREATE','PART',?)")) {
                audit.setString(1, name + " / " + partNumber); audit.executeUpdate();
            }
        } catch (SQLException e) { throw new RuntimeException("Could not add part: " + e.getMessage(), e); }
    }

    @Override
    public void savePart(String userKey, long partId) {
        if (!connected) { demo.savePart(userKey, partId); return; }
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(
                "INSERT IGNORE INTO saved_parts(user_key,part_id) VALUES(?,?)")) {
            ps.setString(1,userKey); ps.setLong(2,partId); ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    @Override
    public void removeSavedPart(String userKey, long partId) {
        if (!connected) { demo.removeSavedPart(userKey, partId); return; }
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(
                "DELETE FROM saved_parts WHERE user_key=? AND part_id=?")) {
            ps.setString(1,userKey); ps.setLong(2,partId); ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    @Override
    public List<Part> savedParts(String userKey) {
        if (!connected) return demo.savedParts(userKey);
        try (Connection c = connection(); PreparedStatement ps = c.prepareStatement(
                "SELECT part_id FROM saved_parts WHERE user_key=? ORDER BY saved_at DESC")) {
            ps.setString(1,userKey);
            try (ResultSet rs = ps.executeQuery()) {
                List<Part> out = new ArrayList<>();
                while (rs.next()) {
                    long id = rs.getLong(1);
                    allParts().stream().filter(p -> p.id() == id).findFirst().ifPresent(out::add);
                }
                return out;
            }
        } catch (SQLException e) { connected = false; return demo.savedParts(userKey); }
    }

    private static class DemoPartsRepository implements PartsRepository {
        private final List<Part> parts = new ArrayList<>(List.of(
            new Part(1,"Engine Air Filter","Bosch","Filters","DEMO-AF-1001","AFTERMARKET",650,"ESTIMATE","Example Parts Supplier","https://example.com/","Unknown","Possible fitment · demo mapping","Pleated filter media; confirm dimensions."),
            new Part(2,"Oil Filter","Denso","Filters","DEMO-OF-2040","AFTERMARKET",420,"ESTIMATE","Example Parts Supplier","https://example.com/","Unknown","Possible fitment · demo mapping","Thread and bypass specs require verification."),
            new Part(3,"Front Brake Pad Set","Example Genuine Parts","Braking","DEMO-BP-3010","UNVERIFIED",1450,"ESTIMATE","Sample Auto Spares","https://example.org/","Unknown","Unknown fitment · demo mapping","Axle position and caliper application must match."),
            new Part(4,"Spark Plug","NGK","Electrical","DEMO-SP-4012","AFTERMARKET",280,"ESTIMATE","Sample Auto Spares","https://example.org/","Unknown","Possible fitment · demo mapping","Heat range, reach and thread must match."),
            new Part(5,"Shock Absorber","Monroe","Suspension","DEMO-SA-5011","AFTERMARKET",2200,"ESTIMATE","Example Parts Supplier","https://example.com/","Unknown","Unknown fitment · demo mapping","Confirm axle and mounting configuration.")
        ));
        private final List<Vehicle> vehicles = List.of(
            new Vehicle(1,"Demo Motors","City Hatch",2022,"1.2 Petrol","1.2L Petrol","Car"),
            new Vehicle(2,"Demo Motors","City Hatch",2023,"1.2 Petrol","1.2L Petrol","Car"),
            new Vehicle(3,"Sample Auto","Urban Compact",2021,"1.0 Turbo","1.0L Turbo","Car"),
            new Vehicle(4,"Sample Moto","Commuter 125",2023,"Standard","125cc","Motorcycle")
        );
        private final List<Supplier> suppliers = List.of(
            new Supplier(1,"Example Parts Supplier","Demo location","https://example.com/",false,"ACTIVE"),
            new Supplier(2,"Sample Auto Spares","Demo location","https://example.org/",false,"ACTIVE")
        );
        private final Map<String, Set<Long>> saved = new HashMap<>();
        @Override public List<Part> findParts(String query, String category, String brand) {
            String q = query == null ? "" : query.toLowerCase(Locale.ROOT).trim();
            return parts.stream().filter(p -> q.isBlank() || (p.name()+" "+p.brand()+" "+p.partNumber()+" "+p.category()).toLowerCase(Locale.ROOT).contains(q))
                .filter(p -> category == null || category.equals("All categories") || p.category().equals(category))
                .filter(p -> brand == null || brand.equals("All brands") || p.brand().equals(brand))
                .collect(Collectors.toList());
        }
        @Override public List<Part> allParts() { return List.copyOf(parts); }
        @Override public List<Vehicle> allVehicles() { return vehicles; }
        @Override public List<Part> partsForVehicle(long vehicleId) {
            if (vehicleId == 1) return parts.stream().filter(p -> p.id() <= 3).toList();
            if (vehicleId == 4) return parts.stream().filter(p -> p.id() == 4).toList();
            if (vehicleId == 3) return parts.stream().filter(p -> p.id() == 5).toList();
            return List.of();
        }
        @Override public List<Supplier> allSuppliers() { return suppliers; }
        @Override public List<String> allBrands() { return List.of("All brands","Bosch","Denso","Example Genuine Parts","NGK","Monroe"); }
        @Override public List<String> allCategories() { return List.of("All categories","Filters","Braking","Electrical","Engine","Suspension","Cooling","Body & Accessories"); }
        @Override public void addPart(String name, String brand, String category, String partNumber, String classification, String description, String specs) {
            long id = parts.stream().mapToLong(Part::id).max().orElse(0)+1;
            parts.add(new Part(id,name,brand,category,partNumber,classification,0,"UNKNOWN","No source","", "Unknown","Not mapped",""+specs));
        }
        @Override public void savePart(String userKey, long partId) { saved.computeIfAbsent(userKey,k->new LinkedHashSet<>()).add(partId); }
        @Override public void removeSavedPart(String userKey, long partId) { Set<Long> ids = saved.get(userKey); if (ids != null) ids.remove(partId); }
        @Override public List<Part> savedParts(String userKey) {
            Set<Long> ids = saved.getOrDefault(userKey,Set.of());
            return parts.stream().filter(p -> ids.contains(p.id())).toList();
        }
        @Override public boolean isDatabaseConnected() { return false; }
    }
}
