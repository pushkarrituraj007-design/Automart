package com.automart;

import com.automart.data.JdbcPartsRepository;
import com.automart.ui.Ui;
import javafx.application.Application;
import javafx.stage.Stage;

public class MainApp extends Application {
    @Override
    public void start(Stage stage) {
        JdbcPartsRepository repository = new JdbcPartsRepository();
        Ui ui = new Ui(stage, repository);
        stage.setTitle("AutoMart | Automotive Parts Intelligence · Beta 0.1");
        stage.setMinWidth(1120);
        stage.setMinHeight(720);
        stage.setScene(ui.createScene());
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
