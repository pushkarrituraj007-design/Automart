package com.automart.data;

public record Part(
        long id,
        String name,
        String brand,
        String category,
        String partNumber,
        String classification,
        double price,
        String priceType,
        String source,
        String sourceUrl,
        String availability,
        String compatibility,
        String specs
) {
    public String priceText() {
        return price > 0 ? String.format("₹%,.0f", price) : "Price on request";
    }
}
