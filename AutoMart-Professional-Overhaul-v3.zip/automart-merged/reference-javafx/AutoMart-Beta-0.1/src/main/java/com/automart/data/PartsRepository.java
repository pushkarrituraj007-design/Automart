package com.automart.data;

import java.util.List;
import java.util.Optional;

public interface PartsRepository {
    List<Part> findParts(String query, String category, String brand);
    List<Part> allParts();
    List<Vehicle> allVehicles();
    List<Part> partsForVehicle(long vehicleId);
    List<Supplier> allSuppliers();
    List<String> allBrands();
    List<String> allCategories();
    void addPart(String name, String brand, String category, String partNumber, String classification,
                 String description, String specs);
    void savePart(String userKey, long partId);
    void removeSavedPart(String userKey, long partId);
    List<Part> savedParts(String userKey);
    boolean isDatabaseConnected();
}
