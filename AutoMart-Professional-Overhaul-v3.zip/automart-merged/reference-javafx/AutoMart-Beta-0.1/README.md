# AutoMart Beta 0.1

A JavaFX desktop MVP for an automotive parts discovery and sourcing marketplace.

## Included in this beta

- Java 21 + JavaFX desktop interface (no Swing)
- Parts-first home and catalogue
- Search by part name, brand, part number or category
- Vehicle selection and sample fitment mapping
- Part comparison (up to four selected parts)
- Save/remove parts in My Garage
- OEM/brand directory and supplier directory
- Admin catalogue view and add-part form
- MySQL schema + sample data
- Demo mode when MySQL is not configured or unavailable

> Demo-mode changes exist only for the current app session. Connect MySQL for persistent storage.

## Requirements

- JDK 21
- Maven 3.9+
- Optional: MySQL 8.0+

## Run in demo mode

From this folder:

```bash
mvn clean javafx:run
```

Maven must be able to download JavaFX and the MySQL driver on first run.

## Configure MySQL

1. Start MySQL.
2. Run `database/schema.sql` using a MySQL client.
3. Run `database/sample-data.sql`.
4. Create a local database account with permissions limited to the `automart` database.
5. Set environment variables before launching:

macOS/Linux:

```bash
export AUTOMART_DB_URL='jdbc:mysql://localhost:3306/automart?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC'
export AUTOMART_DB_USER='automart_app'
export AUTOMART_DB_PASSWORD='YOUR_LOCAL_PASSWORD'
mvn clean javafx:run
```

Windows PowerShell:

```powershell
$env:AUTOMART_DB_URL="jdbc:mysql://localhost:3306/automart?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"
$env:AUTOMART_DB_USER="automart_app"
$env:AUTOMART_DB_PASSWORD="YOUR_LOCAL_PASSWORD"
mvn clean javafx:run
```

If the connection fails, the application logs the reason to the console and starts in demo mode. Never put a production password in source code or commit it to Git.

## Suggested local DB account

Run this manually in MySQL after changing the password to a strong, unique one:

```sql
CREATE USER 'automart_app'@'localhost' IDENTIFIED BY 'REPLACE_WITH_A_STRONG_PASSWORD';
GRANT SELECT, INSERT, UPDATE, DELETE ON automart.* TO 'automart_app'@'localhost';
FLUSH PRIVILEGES;
```

The example above is a template, not a live account. Your database username/password are the values you create on your machine.

## Project layout

```text
AutoMart-Beta-0.1/
├── pom.xml
├── README.md
├── .env.example
├── database/
│   ├── schema.sql
│   └── sample-data.sql
└── src/main/
    ├── java/com/automart/
    │   ├── MainApp.java
    │   ├── data/
    │   │   ├── Part.java
    │   │   ├── Vehicle.java
    │   │   ├── Supplier.java
    │   │   ├── PartsRepository.java
    │   │   └── JdbcPartsRepository.java
    │   └── ui/
    │       └── Ui.java
    └── resources/
        └── styles.css
```

## Current limitations

- Sample data is illustrative and must not be represented as live/verified market pricing.
- Fitment coverage is a demonstration dataset; verify compatibility with a trustworthy catalogue before real-world use.
- External supplier links and live inventory feeds are not yet integrated.
- Login/role enforcement, enquiry submission, import wizard, price-history chart and production hardening are Sprint 2+.
- Images are represented with styled product tiles in this initial source beta; authorized product photography can be added later.

## Sprint 2 backlog

1. Add sign-in and enforce roles in service layer.
2. Add full part/vehicle/fitment CRUD and duplicate checks.
3. Add supplier listing and price observation history.
4. Add CSV import preview/validation and error report.
5. Add repair lists with quantity totals.
6. Add tests for search, fitment, comparison and pricing.
7. Add authorized images and improve accessibility/resizing.
